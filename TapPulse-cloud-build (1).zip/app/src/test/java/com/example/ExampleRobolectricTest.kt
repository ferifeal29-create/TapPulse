package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.ScriptRepository
import com.example.data.local.AppDatabase
import com.example.data.model.ClickMode
import com.example.data.model.TargetActionType
import com.example.service.AutoClickEngineBridge
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches TapPulse`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("TapPulse", appName)
    }

    @Test
    fun `engine bridge switches modes and clamps timing safely`() {
        AutoClickEngineBridge.setMode(ClickMode.MULTI, 1080, 2400)
        val multiState = AutoClickEngineBridge.snapshot.value
        assertEquals(ClickMode.MULTI, multiState.mode)
        assertTrue(multiState.targets.size >= 2)

        AutoClickEngineBridge.updateTimingConfig(intervalMs = 5L, holdDurationMs = 2L)
        val clamped = AutoClickEngineBridge.snapshot.value
        assertEquals(25L, clamped.intervalMs)
        assertEquals(15L, clamped.holdDurationMs)

        AutoClickEngineBridge.setMode(ClickMode.SWIPE, 1080, 2400)
        val swipeState = AutoClickEngineBridge.snapshot.value
        assertEquals(ClickMode.SWIPE, swipeState.mode)
        assertEquals(TargetActionType.SWIPE, swipeState.targets.first().actionType)
    }

    @Test
    fun `repository seeds starter presets into room`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = ScriptRepository(db.scriptDao())
            repo.ensureStarterPresets(1080, 2400)
            val scripts = repo.scriptsFlow.first()
            assertEquals(3, scripts.size)
        } finally {
            db.close()
        }
    }
}
