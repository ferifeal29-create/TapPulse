package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.SystemClock
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.example.data.model.ClickMode
import com.example.data.model.ClickTarget
import com.example.data.model.StopConditionType
import com.example.data.model.TargetActionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.random.Random

class AutoClickAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var overlayController: FloatingOverlayController? = null
    private var clickLoopJob: Job? = null
    private var commandCollectorJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayController = FloatingOverlayController(this, wm)
        AutoClickEngineBridge.setServiceConnected(true)

        commandCollectorJob?.cancel()
        commandCollectorJob = serviceScope.launch {
            AutoClickEngineBridge.commands.collect { command ->
                when (command) {
                    EngineCommand.ShowOverlay -> {
                        overlayController?.showOrUpdate(AutoClickEngineBridge.snapshot.value)
                    }
                    EngineCommand.HideOverlay -> {
                        stopClickingLoop()
                        overlayController?.hideOverlay()
                    }
                    EngineCommand.StartClicking -> {
                        startClickingLoop()
                    }
                    EngineCommand.StopClicking -> {
                        stopClickingLoop()
                    }
                    EngineCommand.SyncOverlayViews -> {
                        val snap = AutoClickEngineBridge.snapshot.value
                        if (snap.isOverlayVisible) {
                            overlayController?.showOrUpdate(snap)
                        }
                    }
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No screen content inspection needed; gestures are dispatched strictly on user command.
    }

    override fun onInterrupt() {
        stopClickingLoop()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanupService()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanupService()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun cleanupService() {
        stopClickingLoop()
        overlayController?.hideOverlay()
        overlayController = null
        commandCollectorJob?.cancel()
        commandCollectorJob = null
        AutoClickEngineBridge.setServiceConnected(false)
    }

    private fun stopClickingLoop() {
        clickLoopJob?.cancel()
        clickLoopJob = null
        AutoClickEngineBridge.setClickingActive(false)
        overlayController?.updateRunningState(AutoClickEngineBridge.snapshot.value)
    }

    private fun startClickingLoop() {
        if (clickLoopJob?.isActive == true) return
        val initialSnap = AutoClickEngineBridge.snapshot.value
        if (initialSnap.targets.isEmpty()) {
            AutoClickEngineBridge.setError("Tambahkan minimal satu titik target sebelum memulai.")
            return
        }

        AutoClickEngineBridge.resetTelemetry()
        AutoClickEngineBridge.setClickingActive(true)
        overlayController?.updateRunningState(AutoClickEngineBridge.snapshot.value)

        clickLoopJob = serviceScope.launch {
            val startElapsedMs = SystemClock.elapsedRealtime()
            var totalClicks = 0L
            var completedCycles = 0

            try {
                while (isActive && AutoClickEngineBridge.snapshot.value.isClickingActive) {
                    val snap = AutoClickEngineBridge.snapshot.value
                    val activeTargets = if (snap.mode == ClickMode.SINGLE) {
                        snap.targets.take(1)
                    } else {
                        snap.targets
                    }
                    if (activeTargets.isEmpty()) break

                    if (snap.stopConditionType == StopConditionType.COUNT && completedCycles >= snap.stopCount) {
                        break
                    }
                    if (snap.stopConditionType == StopConditionType.TIMER &&
                        (SystemClock.elapsedRealtime() - startElapsedMs) >= snap.stopTimerSeconds * 1000L
                    ) {
                        break
                    }

                    for (target in activeTargets) {
                        if (!isActive || !AutoClickEngineBridge.snapshot.value.isClickingActive) break

                        val latest = AutoClickEngineBridge.snapshot.value
                        if (latest.stopConditionType == StopConditionType.TIMER &&
                            (SystemClock.elapsedRealtime() - startElapsedMs) >= latest.stopTimerSeconds * 1000L
                        ) {
                            break
                        }

                        val dispatched = dispatchTargetGesture(target, latest)
                        if (dispatched) {
                            totalClicks++
                        }
                        val elapsed = SystemClock.elapsedRealtime() - startElapsedMs
                        AutoClickEngineBridge.updateSessionTelemetry(totalClicks, elapsed)
                        overlayController?.updateRunningState(AutoClickEngineBridge.snapshot.value)

                        val baseDelay = if (latest.mode == ClickMode.SINGLE) {
                            latest.intervalMs
                        } else {
                            target.delayAfterMs
                        }
                        val waitMs = computeDelayMs(baseDelay, latest.randomizeTiming)
                        delay(waitMs)
                    }

                    completedCycles++
                }
            } finally {
                AutoClickEngineBridge.setClickingActive(false)
                overlayController?.updateRunningState(AutoClickEngineBridge.snapshot.value)
            }
        }
    }

    private fun computeDelayMs(baseDelayMs: Long, randomize: Boolean): Long {
        val safeBase = baseDelayMs.coerceAtLeast(25L)
        if (!randomize) return safeBase
        val spread = (safeBase * 0.15f).toLong().coerceAtLeast(5L)
        val delta = Random.nextLong(-spread, spread + 1L)
        return (safeBase + delta).coerceAtLeast(25L)
    }

    private suspend fun dispatchTargetGesture(
        target: ClickTarget,
        snapshot: EngineSnapshot,
    ): Boolean {
        val jitterX = if (snapshot.randomizePosition) Random.nextFloat() * 12f - 6f else 0f
        val jitterY = if (snapshot.randomizePosition) Random.nextFloat() * 12f - 6f else 0f
        val sx = (target.x + jitterX).coerceAtLeast(1f)
        val sy = (target.y + jitterY).coerceAtLeast(1f)

        val gestureBuilder = GestureDescription.Builder()
        val durationMs = if (target.actionType == TargetActionType.SWIPE &&
            target.endX != null && target.endY != null
        ) {
            val ex = (target.endX + jitterX).coerceAtLeast(1f)
            val ey = (target.endY + jitterY).coerceAtLeast(1f)
            val path = Path().apply {
                moveTo(sx, sy)
                lineTo(ex, ey)
            }
            val swipeMs = target.holdDurationMs.coerceIn(150L, 4000L)
            gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0L, swipeMs))
            swipeMs
        } else {
            val path = Path().apply { moveTo(sx, sy) }
            val holdMs = if (snapshot.mode == ClickMode.SINGLE) {
                snapshot.holdDurationMs.coerceIn(15L, 5000L)
            } else {
                target.holdDurationMs.coerceIn(15L, 5000L)
            }
            gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0L, holdMs))
            holdMs
        }

        val gesture = gestureBuilder.build()
        return withTimeoutOrNull(durationMs + 1500L) {
            suspendCancellableCoroutine { cont ->
                val accepted = dispatchGesture(
                    gesture,
                    object : GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) {
                            if (cont.isActive) cont.resume(true)
                        }

                        override fun onCancelled(gestureDescription: GestureDescription?) {
                            if (cont.isActive) cont.resume(false)
                        }
                    },
                    null,
                )
                if (!accepted && cont.isActive) {
                    cont.resume(false)
                }
            }
        } ?: false
    }
}
