package com.example.service

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.example.data.model.ClickMode
import com.example.data.model.ClickScript
import com.example.data.model.ClickTarget
import com.example.data.model.OverlayAppearancePrefs
import com.example.data.model.StopConditionType
import com.example.data.model.TargetActionType
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong

data class EngineSnapshot(
    val isServiceConnected: Boolean = false,
    val isOverlayVisible: Boolean = false,
    val isClickingActive: Boolean = false,
    val activeScriptId: Long? = null,
    val activeScriptName: String = "Konfigurasi Cepat",
    val mode: ClickMode = ClickMode.SINGLE,
    val intervalMs: Long = 120L,
    val holdDurationMs: Long = 45L,
    val stopConditionType: StopConditionType = StopConditionType.INFINITE,
    val stopCount: Int = 100,
    val stopTimerSeconds: Int = 60,
    val randomizeTiming: Boolean = false,
    val randomizePosition: Boolean = false,
    val targets: List<ClickTarget> = emptyList(),
    val sessionClicks: Long = 0L,
    val sessionElapsedMs: Long = 0L,
    val overlayOpacity: Float = 0.92f,
    val targetBubbleSizeDp: Int = 46,
    val lastError: String? = null,
)

sealed interface EngineCommand {
    data object ShowOverlay : EngineCommand
    data object HideOverlay : EngineCommand
    data object StartClicking : EngineCommand
    data object StopClicking : EngineCommand
    data object SyncOverlayViews : EngineCommand
}

object AutoClickEngineBridge {
    private val nextTargetId = AtomicLong(1L)

    private val _snapshot = MutableStateFlow(EngineSnapshot())
    val snapshot: StateFlow<EngineSnapshot> = _snapshot.asStateFlow()

    private val _commands = MutableSharedFlow<EngineCommand>(extraBufferCapacity = 32)
    val commands: SharedFlow<EngineCommand> = _commands.asSharedFlow()

    fun isAccessibilityEnabledInSettings(context: Context): Boolean {
        if (_snapshot.value.isServiceConnected) return true
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val expectedComponent = ComponentName(context, AutoClickAccessibilityService::class.java)
        val enabledByManager = am?.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK,
        )?.any {
            val serviceInfo = it.resolveInfo?.serviceInfo
            serviceInfo != null &&
                serviceInfo.packageName == expectedComponent.packageName &&
                serviceInfo.name == expectedComponent.className
        } == true
        if (enabledByManager) return true

        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        return enabledServices.split(':')
            .mapNotNull { ComponentName.unflattenFromString(it) }
            .any { it == expectedComponent }
    }

    fun setServiceConnected(connected: Boolean) {
        _snapshot.update { current ->
            if (!connected) {
                current.copy(
                    isServiceConnected = false,
                    isOverlayVisible = false,
                    isClickingActive = false,
                )
            } else {
                current.copy(isServiceConnected = true, lastError = null)
            }
        }
    }

    fun setOverlayVisible(visible: Boolean) {
        _snapshot.update { current ->
            current.copy(
                isOverlayVisible = visible,
                isClickingActive = if (!visible) false else current.isClickingActive,
            )
        }
    }

    fun setClickingActive(active: Boolean) {
        _snapshot.update { current ->
            current.copy(
                isClickingActive = active,
                lastError = if (active) null else current.lastError,
            )
        }
    }

    fun updateSessionTelemetry(clicks: Long, elapsedMs: Long) {
        _snapshot.update {
            it.copy(sessionClicks = clicks, sessionElapsedMs = elapsedMs)
        }
    }

    fun resetTelemetry() {
        _snapshot.update { it.copy(sessionClicks = 0L, sessionElapsedMs = 0L) }
    }

    fun setError(message: String?) {
        _snapshot.update { it.copy(lastError = message) }
    }

    fun ensureDefaultTargets(screenWidthPx: Int, screenHeightPx: Int) {
        val current = _snapshot.value
        if (current.targets.isNotEmpty()) return
        val cx = (screenWidthPx * 0.5f).coerceAtLeast(180f)
        val cy = (screenHeightPx * 0.52f).coerceAtLeast(360f)
        val initial = when (current.mode) {
            ClickMode.SWIPE -> listOf(
                ClickTarget(
                    id = nextTargetId.getAndIncrement(),
                    orderIndex = 1,
                    actionType = TargetActionType.SWIPE,
                    x = cx,
                    y = (screenHeightPx * 0.68f).coerceAtLeast(500f),
                    endX = cx,
                    endY = (screenHeightPx * 0.30f).coerceAtLeast(220f),
                    delayAfterMs = current.intervalMs.coerceAtLeast(500L),
                    holdDurationMs = 360L,
                ),
            )
            else -> listOf(
                ClickTarget(
                    id = nextTargetId.getAndIncrement(),
                    orderIndex = 1,
                    actionType = TargetActionType.TAP,
                    x = cx,
                    y = cy,
                    delayAfterMs = current.intervalMs,
                    holdDurationMs = current.holdDurationMs,
                ),
            )
        }
        _snapshot.update { it.copy(targets = initial) }
    }

    fun setMode(mode: ClickMode, screenWidthPx: Int, screenHeightPx: Int) {
        val cx = (screenWidthPx * 0.5f).coerceAtLeast(180f)
        val cy = (screenHeightPx * 0.52f).coerceAtLeast(360f)
        _snapshot.update { current ->
            val newTargets = when (mode) {
                ClickMode.SINGLE -> {
                    val firstTap = current.targets.firstOrNull { it.actionType == TargetActionType.TAP }
                    listOf(
                        (firstTap ?: ClickTarget(
                            id = nextTargetId.getAndIncrement(),
                            orderIndex = 1,
                            actionType = TargetActionType.TAP,
                            x = cx,
                            y = cy,
                            delayAfterMs = current.intervalMs,
                            holdDurationMs = current.holdDurationMs,
                        )).copy(orderIndex = 1),
                    )
                }
                ClickMode.MULTI -> {
                    val taps = current.targets.filter { it.actionType == TargetActionType.TAP }
                    if (taps.size >= 2) {
                        taps.mapIndexed { idx, t -> t.copy(orderIndex = idx + 1) }
                    } else {
                        val first = taps.firstOrNull() ?: ClickTarget(
                            id = nextTargetId.getAndIncrement(),
                            orderIndex = 1,
                            actionType = TargetActionType.TAP,
                            x = cx - 90f,
                            y = cy - 90f,
                            delayAfterMs = current.intervalMs,
                            holdDurationMs = current.holdDurationMs,
                        )
                        val second = ClickTarget(
                            id = nextTargetId.getAndIncrement(),
                            orderIndex = 2,
                            actionType = TargetActionType.TAP,
                            x = (first.x + 160f).coerceAtMost(screenWidthPx - 80f),
                            y = (first.y + 140f).coerceAtMost(screenHeightPx - 140f),
                            delayAfterMs = current.intervalMs,
                            holdDurationMs = current.holdDurationMs,
                        )
                        listOf(first.copy(orderIndex = 1), second)
                    }
                }
                ClickMode.SWIPE -> {
                    val firstSwipe = current.targets.firstOrNull { it.actionType == TargetActionType.SWIPE }
                    val swipeTarget = firstSwipe ?: ClickTarget(
                        id = nextTargetId.getAndIncrement(),
                        orderIndex = 1,
                        actionType = TargetActionType.SWIPE,
                        x = cx,
                        y = (screenHeightPx * 0.68f).coerceAtLeast(500f),
                        endX = cx,
                        endY = (screenHeightPx * 0.30f).coerceAtLeast(220f),
                        delayAfterMs = current.intervalMs.coerceAtLeast(600L),
                        holdDurationMs = 360L,
                    )
                    listOf(swipeTarget.copy(orderIndex = 1))
                }
            }
            current.copy(
                mode = mode,
                isClickingActive = false,
                targets = newTargets,
                intervalMs = if (mode == ClickMode.SWIPE && current.intervalMs < 400L) 1200L else current.intervalMs,
                holdDurationMs = if (mode == ClickMode.SWIPE && current.holdDurationMs < 150L) 360L else current.holdDurationMs,
            )
        }
        _commands.tryEmit(EngineCommand.SyncOverlayViews)
    }

    fun addTarget(
        actionType: TargetActionType,
        screenWidthPx: Int,
        screenHeightPx: Int,
    ) {
        _snapshot.update { current ->
            val count = current.targets.size
            val offset = (count % 5) * 65f
            val baseX = (screenWidthPx * 0.45f + offset).coerceIn(100f, (screenWidthPx - 100f).coerceAtLeast(120f))
            val baseY = (screenHeightPx * 0.45f + offset).coerceIn(180f, (screenHeightPx - 180f).coerceAtLeast(200f))
            val newTarget = if (actionType == TargetActionType.SWIPE) {
                ClickTarget(
                    id = nextTargetId.getAndIncrement(),
                    orderIndex = count + 1,
                    actionType = TargetActionType.SWIPE,
                    x = baseX,
                    y = (baseY + 140f).coerceAtMost((screenHeightPx - 140f).coerceAtLeast(220f)),
                    endX = baseX,
                    endY = (baseY - 140f).coerceAtLeast(140f),
                    delayAfterMs = current.intervalMs.coerceAtLeast(500L),
                    holdDurationMs = 360L,
                )
            } else {
                ClickTarget(
                    id = nextTargetId.getAndIncrement(),
                    orderIndex = count + 1,
                    actionType = TargetActionType.TAP,
                    x = baseX,
                    y = baseY,
                    delayAfterMs = current.intervalMs,
                    holdDurationMs = current.holdDurationMs,
                )
            }
            val updatedTargets = if (current.mode == ClickMode.SINGLE) {
                listOf(newTarget.copy(orderIndex = 1))
            } else {
                current.targets + newTarget
            }
            val nextMode = if (updatedTargets.size > 1 && current.mode == ClickMode.SINGLE) {
                ClickMode.MULTI
            } else if (actionType == TargetActionType.SWIPE && updatedTargets.size == 1) {
                ClickMode.SWIPE
            } else {
                current.mode
            }
            current.copy(targets = updatedTargets, mode = nextMode)
        }
        _commands.tryEmit(EngineCommand.SyncOverlayViews)
    }

    fun removeLastTarget() {
        _snapshot.update { current ->
            if (current.targets.size <= 1) return@update current
            val trimmed = current.targets.dropLast(1).mapIndexed { idx, t ->
                t.copy(orderIndex = idx + 1)
            }
            current.copy(targets = trimmed)
        }
        _commands.tryEmit(EngineCommand.SyncOverlayViews)
    }

    fun removeTargetById(targetId: Long) {
        _snapshot.update { current ->
            if (current.targets.size <= 1) return@update current
            val trimmed = current.targets.filterNot { it.id == targetId }
                .mapIndexed { idx, t -> t.copy(orderIndex = idx + 1) }
            current.copy(targets = trimmed)
        }
        _commands.tryEmit(EngineCommand.SyncOverlayViews)
    }

    fun updateTargetPosition(targetId: Long, x: Float, y: Float, isEndPoint: Boolean = false) {
        _snapshot.update { current ->
            val updated = current.targets.map { target ->
                if (target.id == targetId) {
                    if (isEndPoint) {
                        target.copy(endX = x, endY = y)
                    } else {
                        target.copy(x = x, y = y)
                    }
                } else {
                    target
                }
            }
            current.copy(targets = updated)
        }
    }

    fun updateTargetTiming(targetId: Long, delayAfterMs: Long, holdDurationMs: Long) {
        _snapshot.update { current ->
            val updated = current.targets.map { t ->
                if (t.id == targetId) {
                    t.copy(
                        delayAfterMs = delayAfterMs.coerceAtLeast(25L),
                        holdDurationMs = holdDurationMs.coerceIn(15L, 5000L),
                    )
                } else {
                    t
                }
            }
            current.copy(targets = updated)
        }
    }

    fun updateTimingConfig(
        intervalMs: Long? = null,
        holdDurationMs: Long? = null,
        stopConditionType: StopConditionType? = null,
        stopCount: Int? = null,
        stopTimerSeconds: Int? = null,
        randomizeTiming: Boolean? = null,
        randomizePosition: Boolean? = null,
    ) {
        _snapshot.update { current ->
            val nextInterval = (intervalMs ?: current.intervalMs).coerceAtLeast(25L)
            val nextHold = (holdDurationMs ?: current.holdDurationMs).coerceIn(15L, 5000L)
            val updatedTargets = if (intervalMs != null && current.mode == ClickMode.SINGLE) {
                current.targets.map { it.copy(delayAfterMs = nextInterval, holdDurationMs = nextHold) }
            } else if (holdDurationMs != null && current.mode == ClickMode.SINGLE) {
                current.targets.map { it.copy(holdDurationMs = nextHold) }
            } else {
                current.targets
            }
            current.copy(
                intervalMs = nextInterval,
                holdDurationMs = nextHold,
                stopConditionType = stopConditionType ?: current.stopConditionType,
                stopCount = (stopCount ?: current.stopCount).coerceAtLeast(1),
                stopTimerSeconds = (stopTimerSeconds ?: current.stopTimerSeconds).coerceAtLeast(1),
                randomizeTiming = randomizeTiming ?: current.randomizeTiming,
                randomizePosition = randomizePosition ?: current.randomizePosition,
                targets = updatedTargets,
            )
        }
        _commands.tryEmit(EngineCommand.SyncOverlayViews)
    }

    fun loadScript(script: ClickScript) {
        val loadedTargets = script.targets.mapIndexed { idx, t ->
            t.copy(id = nextTargetId.getAndIncrement(), orderIndex = idx + 1)
        }
        _snapshot.update { current ->
            current.copy(
                isClickingActive = false,
                activeScriptId = script.id,
                activeScriptName = script.name,
                mode = script.mode,
                intervalMs = script.intervalMs,
                holdDurationMs = script.holdDurationMs,
                stopConditionType = script.stopConditionType,
                stopCount = script.stopCount,
                stopTimerSeconds = script.stopTimerSeconds,
                randomizeTiming = script.randomizeTiming,
                randomizePosition = script.randomizePosition,
                targets = loadedTargets,
                sessionClicks = 0L,
                sessionElapsedMs = 0L,
                lastError = null,
            )
        }
        _commands.tryEmit(EngineCommand.SyncOverlayViews)
    }

    fun applyAppearancePrefs(prefs: OverlayAppearancePrefs) {
        _snapshot.update {
            it.copy(
                overlayOpacity = prefs.overlayOpacity,
                targetBubbleSizeDp = prefs.targetBubbleSizeDp,
            )
        }
        _commands.tryEmit(EngineCommand.SyncOverlayViews)
    }

    fun requestShowOverlay() {
        _commands.tryEmit(EngineCommand.ShowOverlay)
    }

    fun requestHideOverlay() {
        _commands.tryEmit(EngineCommand.HideOverlay)
    }

    fun requestStartClicking() {
        _commands.tryEmit(EngineCommand.StartClicking)
    }

    fun requestStopClicking() {
        _commands.tryEmit(EngineCommand.StopClicking)
    }
}
