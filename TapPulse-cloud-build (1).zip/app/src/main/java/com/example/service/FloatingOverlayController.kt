package com.example.service

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.ClickMode
import com.example.data.model.ClickTarget
import com.example.data.model.TargetActionType
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class FloatingOverlayController(
    private val context: Context,
    private val windowManager: WindowManager,
) {
    private var controlBarView: View? = null
    private var controlBarParams: WindowManager.LayoutParams? = null
    private var playPauseIcon: ImageView? = null
    private var statusBadgeText: TextView? = null

    private var swipePathView: SwipePathOverlayView? = null
    private var swipePathParams: WindowManager.LayoutParams? = null

    private var quickEditPopupView: View? = null
    private var quickEditPopupParams: WindowManager.LayoutParams? = null
    private var quickEditTargetId: Long? = null

    private data class TargetHolder(
        val targetId: Long,
        val isEndPoint: Boolean,
        val view: TargetCrosshairView,
        val params: WindowManager.LayoutParams,
    )

    private val targetHolders = mutableListOf<TargetHolder>()

    private fun dp(value: Float): Int {
        return (value * context.resources.displayMetrics.density).toInt()
    }

    private fun screenMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay?.getRealMetrics(metrics)
        return metrics
    }

    fun showOrUpdate(snapshot: EngineSnapshot) {
        val metrics = screenMetrics()
        AutoClickEngineBridge.ensureDefaultTargets(metrics.widthPixels, metrics.heightPixels)
        val latest = AutoClickEngineBridge.snapshot.value

        if (controlBarView == null) {
            createControlBar(latest, metrics)
        }
        updateControlBarVisuals(latest)
        syncTargetMarkers(latest, metrics)
        syncSwipeLine(latest)
        AutoClickEngineBridge.setOverlayVisible(true)
    }

    fun updateRunningState(snapshot: EngineSnapshot) {
        updateControlBarVisuals(snapshot)
        // Make target markers pass touches through while running so taps hit the app below!
        targetHolders.forEach { holder ->
            val desiredFlags = if (snapshot.isClickingActive) {
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            } else {
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            }
            if (holder.params.flags != desiredFlags) {
                holder.params.flags = desiredFlags
                runCatching { windowManager.updateViewLayout(holder.view, holder.params) }
            }
            holder.view.setRunning(snapshot.isClickingActive)
        }
        if (snapshot.isClickingActive) {
            dismissQuickEditPopup()
        }
    }

    fun hideOverlay() {
        dismissQuickEditPopup()
        targetHolders.forEach { holder ->
            runCatching { windowManager.removeViewImmediate(holder.view) }
        }
        targetHolders.clear()

        swipePathView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        swipePathView = null
        swipePathParams = null

        controlBarView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        controlBarView = null
        controlBarParams = null
        playPauseIcon = null
        statusBadgeText = null

        AutoClickEngineBridge.setOverlayVisible(false)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createControlBar(snapshot: EngineSnapshot, metrics: DisplayMetrics) {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8f), dp(10f), dp(8f), dp(10f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24f).toFloat()
                setColor(Color.parseColor("#EC0F1826"))
                setStroke(dp(1.5f), Color.parseColor("#00E5CC"))
            }
            elevation = dp(10f).toFloat()
            alpha = snapshot.overlayOpacity
        }

        // Drag handle bar
        val dragHandle = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(26f), dp(5f)).apply {
                bottomMargin = dp(8f)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(3f).toFloat()
                setColor(Color.parseColor("#64748B"))
            }
        }
        container.addView(dragHandle)

        // Play / Pause button
        val playBtn = createCircleButton(
            iconRes = android.R.drawable.ic_media_play,
            bgColor = "#00E5CC",
            tintColor = "#00201C",
            contentDesc = "Mulai atau jeda ketuk otomatis",
        ) {
            val current = AutoClickEngineBridge.snapshot.value
            if (current.isClickingActive) {
                AutoClickEngineBridge.requestStopClicking()
            } else {
                AutoClickEngineBridge.requestStartClicking()
            }
        }
        playPauseIcon = playBtn
        container.addView(playBtn)

        // Status / Click counter pill
        val badge = TextView(context).apply {
            text = "${snapshot.intervalMs}ms"
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#7BF8E5"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply {
                topMargin = dp(4f)
                bottomMargin = dp(6f)
            }
        }
        statusBadgeText = badge
        container.addView(badge)

        // Add Target (+)
        val addBtn = createCircleButton(
            iconRes = android.R.drawable.ic_input_add,
            bgColor = "#1E2F47",
            tintColor = "#F1F5F9",
            contentDesc = "Tambah titik target",
        ) {
            val current = AutoClickEngineBridge.snapshot.value
            if (!current.isClickingActive) {
                val m = screenMetrics()
                val type = if (current.mode == ClickMode.SWIPE) {
                    TargetActionType.SWIPE
                } else {
                    TargetActionType.TAP
                }
                AutoClickEngineBridge.addTarget(type, m.widthPixels, m.heightPixels)
            }
        }
        container.addView(addBtn)

        // Remove Last Target (-)
        val removeBtn = createCircleButton(
            iconRes = android.R.drawable.ic_delete,
            bgColor = "#1E2F47",
            tintColor = "#F1F5F9",
            contentDesc = "Hapus titik target terakhir",
        ) {
            if (!AutoClickEngineBridge.snapshot.value.isClickingActive) {
                AutoClickEngineBridge.removeLastTarget()
            }
        }
        container.addView(removeBtn)

        // Close overlay (X)
        val closeBtn = createCircleButton(
            iconRes = android.R.drawable.ic_menu_close_clear_cancel,
            bgColor = "#3B1717",
            tintColor = "#FF6B4A",
            contentDesc = "Tutup panel mengambang",
            bottomMarginDp = 0f,
        ) {
            AutoClickEngineBridge.requestHideOverlay()
        }
        container.addView(closeBtn)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12f)
            y = (metrics.heightPixels * 0.25f).toInt()
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (initialX + (event.rawX - initialTouchX).toInt())
                        .coerceIn(0, (metrics.widthPixels - dp(56f)).coerceAtLeast(0))
                    params.y = (initialY + (event.rawY - initialTouchY).toInt())
                        .coerceIn(dp(24f), (metrics.heightPixels - dp(180f)).coerceAtLeast(dp(24f)))
                    runCatching { windowManager.updateViewLayout(container, params) }
                    true
                }
                else -> false
            }
        }

        controlBarView = container
        controlBarParams = params
        runCatching { windowManager.addView(container, params) }
    }

    private fun createCircleButton(
        iconRes: Int,
        bgColor: String,
        tintColor: String,
        contentDesc: String,
        bottomMarginDp: Float = 6f,
        onClick: () -> Unit,
    ): ImageView {
        return ImageView(context).apply {
            val sizePx = dp(40f)
            layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                bottomMargin = dp(bottomMarginDp)
            }
            setPadding(dp(9f), dp(9f), dp(9f), dp(9f))
            setImageResource(iconRes)
            setColorFilter(Color.parseColor(tintColor))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(bgColor))
            }
            contentDescription = contentDesc
            setOnClickListener { onClick() }
        }
    }

    private fun updateControlBarVisuals(snapshot: EngineSnapshot) {
        controlBarView?.alpha = snapshot.overlayOpacity
        playPauseIcon?.apply {
            if (snapshot.isClickingActive) {
                setImageResource(android.R.drawable.ic_media_pause)
                setColorFilter(Color.parseColor("#2B0900"))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#FF6B4A"))
                }
            } else {
                setImageResource(android.R.drawable.ic_media_play)
                setColorFilter(Color.parseColor("#00201C"))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#00E5CC"))
                }
            }
        }
        statusBadgeText?.apply {
            text = if (snapshot.isClickingActive) {
                "${snapshot.sessionClicks}x"
            } else {
                "${snapshot.intervalMs}ms"
            }
            setTextColor(
                Color.parseColor(if (snapshot.isClickingActive) "#FF9A80" else "#7BF8E5"),
            )
        }
    }

    private fun syncTargetMarkers(snapshot: EngineSnapshot, metrics: DisplayMetrics) {
        // Remove existing target markers and rebuild cleanly
        targetHolders.forEach { holder ->
            runCatching { windowManager.removeViewImmediate(holder.view) }
        }
        targetHolders.clear()

        val sizePx = dp(snapshot.targetBubbleSizeDp.toFloat())
        val halfSize = sizePx / 2f

        snapshot.targets.forEach { target ->
            addTargetMarkerWindow(
                target = target,
                isEndPoint = false,
                sizePx = sizePx,
                halfSize = halfSize,
                snapshot = snapshot,
                metrics = metrics,
            )
            if (target.actionType == TargetActionType.SWIPE && target.endX != null && target.endY != null) {
                addTargetMarkerWindow(
                    target = target,
                    isEndPoint = true,
                    sizePx = sizePx,
                    halfSize = halfSize,
                    snapshot = snapshot,
                    metrics = metrics,
                )
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addTargetMarkerWindow(
        target: ClickTarget,
        isEndPoint: Boolean,
        sizePx: Int,
        halfSize: Float,
        snapshot: EngineSnapshot,
        metrics: DisplayMetrics,
    ) {
        val label = when {
            target.actionType == TargetActionType.SWIPE && !isEndPoint -> "${target.orderIndex}S"
            target.actionType == TargetActionType.SWIPE && isEndPoint -> "${target.orderIndex}E"
            else -> target.orderIndex.toString()
        }
        val markerColor = if (isEndPoint) Color.parseColor("#FF6B4A") else Color.parseColor("#00E5CC")
        val view = TargetCrosshairView(context, label, markerColor).apply {
            alpha = snapshot.overlayOpacity
            setRunning(snapshot.isClickingActive)
        }

        val cx = if (isEndPoint) (target.endX ?: target.x) else target.x
        val cy = if (isEndPoint) (target.endY ?: target.y) else target.y

        val flags = if (snapshot.isClickingActive) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        }

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (cx - halfSize).toInt()
            y = (cy - halfSize).toInt()
        }

        var startWinX = 0
        var startWinY = 0
        var downRawX = 0f
        var downRawY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            if (AutoClickEngineBridge.snapshot.value.isClickingActive) return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startWinX = params.x
                    startWinY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (abs(dx) > dp(4f) || abs(dy) > dp(4f)) {
                        moved = true
                    }
                    params.x = (startWinX + dx.toInt()).coerceIn(
                        -halfSize.toInt() + dp(12f),
                        metrics.widthPixels - halfSize.toInt() - dp(12f),
                    )
                    params.y = (startWinY + dy.toInt()).coerceIn(
                        -halfSize.toInt() + dp(24f),
                        metrics.heightPixels - halfSize.toInt() - dp(24f),
                    )
                    runCatching { windowManager.updateViewLayout(view, params) }

                    val centerX = params.x + halfSize
                    val centerY = params.y + halfSize
                    AutoClickEngineBridge.updateTargetPosition(
                        targetId = target.id,
                        x = centerX,
                        y = centerY,
                        isEndPoint = isEndPoint,
                    )
                    swipePathView?.updateTargets(AutoClickEngineBridge.snapshot.value.targets)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && !isEndPoint) {
                        showQuickEditPopup(target.id, params.x, params.y, metrics)
                    }
                    true
                }
                else -> false
            }
        }

        targetHolders.add(TargetHolder(target.id, isEndPoint, view, params))
        runCatching { windowManager.addView(view, params) }
    }

    private fun syncSwipeLine(snapshot: EngineSnapshot) {
        val hasSwipes = snapshot.targets.any { it.actionType == TargetActionType.SWIPE }
        if (!hasSwipes) {
            swipePathView?.let { runCatching { windowManager.removeViewImmediate(it) } }
            swipePathView = null
            swipePathParams = null
            return
        }

        if (swipePathView == null) {
            val view = SwipePathOverlayView(context)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
            }
            swipePathView = view
            swipePathParams = params
            runCatching { windowManager.addView(view, params) }
        }
        swipePathView?.updateTargets(snapshot.targets)
    }

    private fun showQuickEditPopup(targetId: Long, anchorX: Int, anchorY: Int, metrics: DisplayMetrics) {
        if (quickEditTargetId == targetId && quickEditPopupView != null) {
            dismissQuickEditPopup()
            return
        }
        dismissQuickEditPopup()

        val target = AutoClickEngineBridge.snapshot.value.targets.find { it.id == targetId } ?: return
        quickEditTargetId = targetId

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16f).toFloat()
                setColor(Color.parseColor("#F2101A28"))
                setStroke(dp(1.2f), Color.parseColor("#00E5CC"))
            }
            elevation = dp(12f).toFloat()
        }

        val title = TextView(context).apply {
            text = "Titik #${target.orderIndex} • Jeda ${target.delayAfterMs} ms"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#F1F5F9"))
        }
        card.addView(title)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8f) }
        }

        fun chip(label: String, bg: String, fg: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 12f
                typeface = Typeface.MONOSPACE
                setTextColor(Color.parseColor(fg))
                setPadding(dp(10f), dp(6f), dp(10f), dp(6f))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(10f).toFloat()
                    setColor(Color.parseColor(bg))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ).apply { marginEnd = dp(6f) }
                setOnClickListener { onClick() }
            }
        }

        row.addView(
            chip("-50ms", "#1E2F47", "#F1F5F9") {
                val cur = AutoClickEngineBridge.snapshot.value.targets.find { it.id == targetId } ?: return@chip
                val nextDelay = (cur.delayAfterMs - 50L).coerceAtLeast(25L)
                AutoClickEngineBridge.updateTargetTiming(targetId, nextDelay, cur.holdDurationMs)
                title.text = "Titik #${cur.orderIndex} • Jeda $nextDelay ms"
            },
        )
        row.addView(
            chip("+50ms", "#1E2F47", "#F1F5F9") {
                val cur = AutoClickEngineBridge.snapshot.value.targets.find { it.id == targetId } ?: return@chip
                val nextDelay = (cur.delayAfterMs + 50L).coerceAtMost(60_000L)
                AutoClickEngineBridge.updateTargetTiming(targetId, nextDelay, cur.holdDurationMs)
                title.text = "Titik #${cur.orderIndex} • Jeda $nextDelay ms"
            },
        )
        if (AutoClickEngineBridge.snapshot.value.targets.size > 1) {
            row.addView(
                chip("Hapus", "#3B1717", "#FF6B4A") {
                    dismissQuickEditPopup()
                    AutoClickEngineBridge.removeTargetById(targetId)
                },
            )
        }
        row.addView(
            chip("Tutup", "#004D43", "#7BF8E5") {
                dismissQuickEditPopup()
            },
        )
        card.addView(row)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = anchorX.coerceIn(dp(12f), (metrics.widthPixels - dp(260f)).coerceAtLeast(dp(12f)))
            y = (anchorY - dp(84f)).coerceAtLeast(dp(48f))
        }

        quickEditPopupView = card
        quickEditPopupParams = params
        runCatching { windowManager.addView(card, params) }
    }

    private fun dismissQuickEditPopup() {
        quickEditPopupView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        quickEditPopupView = null
        quickEditPopupParams = null
        quickEditTargetId = null
    }
}

private class TargetCrosshairView(
    context: Context,
    private val label: String,
    private val accentColor: Int,
) : View(context) {

    private var isRunning = false

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(145, 11, 19, 32)
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accentColor
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accentColor
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    fun setRunning(running: Boolean) {
        if (isRunning != running) {
            isRunning = running
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (minOf(width, height) / 2f) - 6f

        fillPaint.alpha = if (isRunning) 90 else 160
        ringPaint.alpha = if (isRunning) 165 else 255
        ringPaint.color = if (isRunning) Color.parseColor("#FF6B4A") else accentColor

        canvas.drawCircle(cx, cy, radius, fillPaint)
        canvas.drawCircle(cx, cy, radius, ringPaint)

        // Precision crosshair ticks
        val tickLen = radius * 0.28f
        canvas.drawLine(cx - radius, cy, cx - radius + tickLen, cy, ringPaint)
        canvas.drawLine(cx + radius - tickLen, cy, cx + radius, cy, ringPaint)
        canvas.drawLine(cx, cy - radius, cx, cy - radius + tickLen, ringPaint)
        canvas.drawLine(cx, cy + radius - tickLen, cx, cy + radius, ringPaint)

        // Label
        textPaint.textSize = radius * 0.68f
        val textY = cy - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(label, cx, textY, textPaint)

        // Small center point dot at bottom edge of label if desired, or keep number centered cleanly
        canvas.drawCircle(cx, cy + radius * 0.56f, 3.5f, centerDotPaint)
    }
}

private class SwipePathOverlayView(context: Context) : View(context) {
    private var targets: List<ClickTarget> = emptyList()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC00E5CC")
        style = Paint.Style.STROKE
        strokeWidth = 7f
        pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
    }

    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFFF6B4A")
        style = Paint.Style.FILL
    }

    fun updateTargets(list: List<ClickTarget>) {
        targets = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        targets.filter { it.actionType == TargetActionType.SWIPE && it.endX != null && it.endY != null }
            .forEach { target ->
                val sx = target.x
                val sy = target.y
                val ex = target.endX!!
                val ey = target.endY!!
                canvas.drawLine(sx, sy, ex, ey, linePaint)

                val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
                val arrowLen = 26f
                val arrowAngle = Math.toRadians(28.0)
                val x1 = (ex - arrowLen * cos(angle - arrowAngle)).toFloat()
                val y1 = (ey - arrowLen * sin(angle - arrowAngle)).toFloat()
                val x2 = (ex - arrowLen * cos(angle + arrowAngle)).toFloat()
                val y2 = (ey - arrowLen * sin(angle + arrowAngle)).toFloat()

                val path = Path().apply {
                    moveTo(ex, ey)
                    lineTo(x1, y1)
                    lineTo(x2, y2)
                    close()
                }
                canvas.drawPath(path, arrowPaint)
            }
    }
}
