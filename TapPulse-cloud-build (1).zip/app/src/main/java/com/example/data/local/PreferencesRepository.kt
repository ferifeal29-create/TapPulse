package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.OverlayAppearancePrefs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "tappulse_prefs")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val OVERLAY_OPACITY = floatPreferencesKey("overlay_opacity")
        val TARGET_BUBBLE_SIZE_DP = intPreferencesKey("target_bubble_size_dp")
        val USE_DYNAMIC_COLOR = booleanPreferencesKey("use_dynamic_color")
        val DEFAULT_INTERVAL_MS = longPreferencesKey("default_interval_ms")
        val DEFAULT_HOLD_MS = longPreferencesKey("default_hold_ms")
    }

    val preferencesFlow: Flow<OverlayAppearancePrefs> = context.dataStore.data.map { prefs ->
        OverlayAppearancePrefs(
            overlayOpacity = prefs[Keys.OVERLAY_OPACITY] ?: 0.92f,
            targetBubbleSizeDp = prefs[Keys.TARGET_BUBBLE_SIZE_DP] ?: 46,
            useDynamicColor = prefs[Keys.USE_DYNAMIC_COLOR] ?: false,
            defaultIntervalMs = prefs[Keys.DEFAULT_INTERVAL_MS] ?: 120L,
            defaultHoldMs = prefs[Keys.DEFAULT_HOLD_MS] ?: 45L,
        )
    }

    suspend fun updateOverlayOpacity(opacity: Float) {
        context.dataStore.edit { it[Keys.OVERLAY_OPACITY] = opacity.coerceIn(0.45f, 1.0f) }
    }

    suspend fun updateTargetBubbleSize(sizeDp: Int) {
        context.dataStore.edit { it[Keys.TARGET_BUBBLE_SIZE_DP] = sizeDp.coerceIn(36, 68) }
    }

    suspend fun updateDynamicColor(enabled: Boolean) {
        context.dataStore.edit { it[Keys.USE_DYNAMIC_COLOR] = enabled }
    }

    suspend fun updateDefaultTimings(intervalMs: Long, holdMs: Long) {
        context.dataStore.edit {
            it[Keys.DEFAULT_INTERVAL_MS] = intervalMs.coerceAtLeast(25L)
            it[Keys.DEFAULT_HOLD_MS] = holdMs.coerceIn(15L, 5000L)
        }
    }
}
