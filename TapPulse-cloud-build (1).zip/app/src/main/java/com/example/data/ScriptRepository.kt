package com.example.data

import com.example.data.local.ClickPointEntity
import com.example.data.local.ClickScriptEntity
import com.example.data.local.ScriptDao
import com.example.data.local.toDomain
import com.example.data.model.ClickMode
import com.example.data.model.ClickScript
import com.example.data.model.StopConditionType
import com.example.data.model.TargetActionType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class ScriptRepository(
    private val scriptDao: ScriptDao,
) {
    private val seedMutex = Mutex()

    val scriptsFlow: Flow<List<ClickScript>> = scriptDao.observeAllScripts().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun ensureStarterPresets(screenWidthPx: Int, screenHeightPx: Int) {
        seedMutex.withLock {
            if (scriptDao.getScriptCount() > 0) return
            val cx = (screenWidthPx * 0.5f).coerceAtLeast(200f)
            val cy = (screenHeightPx * 0.52f).coerceAtLeast(400f)
            val now = System.currentTimeMillis()

            // 1. Rapid Single Tap preset
            scriptDao.saveScriptWithPoints(
                ClickScriptEntity(
                    name = "Ketuk Cepat 100ms",
                    mode = ClickMode.SINGLE.name,
                    intervalMs = 100L,
                    holdDurationMs = 40L,
                    stopConditionType = StopConditionType.INFINITE.name,
                    stopCount = 200,
                    stopTimerSeconds = 60,
                    randomizeTiming = false,
                    randomizePosition = false,
                    updatedAt = now,
                ),
                listOf(
                    ClickPointEntity(
                        scriptId = 0L,
                        orderIndex = 1,
                        actionType = TargetActionType.TAP.name,
                        x = cx,
                        y = cy,
                        delayAfterMs = 100L,
                        holdDurationMs = 40L,
                    ),
                ),
            )

            // 2. Multi-point 3-tap combo preset
            scriptDao.saveScriptWithPoints(
                ClickScriptEntity(
                    name = "Kombo 3 Titik Berantai",
                    mode = ClickMode.MULTI.name,
                    intervalMs = 250L,
                    holdDurationMs = 45L,
                    stopConditionType = StopConditionType.COUNT.name,
                    stopCount = 50,
                    stopTimerSeconds = 60,
                    randomizeTiming = true,
                    randomizePosition = true,
                    updatedAt = now - 1000L,
                ),
                listOf(
                    ClickPointEntity(
                        scriptId = 0L,
                        orderIndex = 1,
                        actionType = TargetActionType.TAP.name,
                        x = cx - 120f,
                        y = cy - 140f,
                        delayAfterMs = 220L,
                        holdDurationMs = 45L,
                    ),
                    ClickPointEntity(
                        scriptId = 0L,
                        orderIndex = 2,
                        actionType = TargetActionType.TAP.name,
                        x = cx + 120f,
                        y = cy,
                        delayAfterMs = 220L,
                        holdDurationMs = 45L,
                    ),
                    ClickPointEntity(
                        scriptId = 0L,
                        orderIndex = 3,
                        actionType = TargetActionType.TAP.name,
                        x = cx,
                        y = cy + 160f,
                        delayAfterMs = 350L,
                        holdDurationMs = 45L,
                    ),
                ),
            )

            // 3. Auto Scroll / Swipe preset
            scriptDao.saveScriptWithPoints(
                ClickScriptEntity(
                    name = "Scroll Baca Otomatis",
                    mode = ClickMode.SWIPE.name,
                    intervalMs = 1800L,
                    holdDurationMs = 380L,
                    stopConditionType = StopConditionType.TIMER.name,
                    stopCount = 100,
                    stopTimerSeconds = 120,
                    randomizeTiming = true,
                    randomizePosition = false,
                    updatedAt = now - 2000L,
                ),
                listOf(
                    ClickPointEntity(
                        scriptId = 0L,
                        orderIndex = 1,
                        actionType = TargetActionType.SWIPE.name,
                        x = cx,
                        y = (screenHeightPx * 0.70f).coerceAtLeast(600f),
                        endX = cx,
                        endY = (screenHeightPx * 0.30f).coerceAtLeast(250f),
                        delayAfterMs = 1800L,
                        holdDurationMs = 380L,
                    ),
                ),
            )
        }
    }

    suspend fun saveScript(script: ClickScript): Long {
        val entity = ClickScriptEntity(
            id = script.id,
            name = script.name.trim().ifEmpty { "Preset Tanpa Nama" },
            mode = script.mode.name,
            intervalMs = script.intervalMs.coerceAtLeast(25L),
            holdDurationMs = script.holdDurationMs.coerceIn(15L, 5000L),
            stopConditionType = script.stopConditionType.name,
            stopCount = script.stopCount.coerceAtLeast(1),
            stopTimerSeconds = script.stopTimerSeconds.coerceAtLeast(1),
            randomizeTiming = script.randomizeTiming,
            randomizePosition = script.randomizePosition,
            updatedAt = System.currentTimeMillis(),
        )
        val pointEntities = script.targets.mapIndexed { idx, t ->
            ClickPointEntity(
                scriptId = script.id,
                orderIndex = idx + 1,
                actionType = t.actionType.name,
                x = t.x,
                y = t.y,
                endX = t.endX,
                endY = t.endY,
                delayAfterMs = t.delayAfterMs.coerceAtLeast(25L),
                holdDurationMs = t.holdDurationMs.coerceIn(15L, 5000L),
            )
        }
        return scriptDao.saveScriptWithPoints(entity, pointEntities)
    }

    suspend fun duplicateScript(script: ClickScript): Long {
        val copy = script.copy(
            id = 0L,
            name = "${script.name} (Salinan)",
            updatedAt = System.currentTimeMillis(),
        )
        return saveScript(copy)
    }

    suspend fun deleteScript(id: Long) {
        scriptDao.deleteScriptById(id)
    }
}
