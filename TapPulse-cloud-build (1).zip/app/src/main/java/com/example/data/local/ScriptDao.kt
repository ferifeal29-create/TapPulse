package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ScriptDao {
    @Transaction
    @Query("SELECT * FROM click_scripts ORDER BY updatedAt DESC")
    fun observeAllScripts(): Flow<List<ClickScriptWithPoints>>

    @Query("SELECT COUNT(*) FROM click_scripts")
    suspend fun getScriptCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScript(script: ClickScriptEntity): Long

    @Update
    suspend fun updateScript(script: ClickScriptEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPoints(points: List<ClickPointEntity>)

    @Query("DELETE FROM click_points WHERE scriptId = :scriptId")
    suspend fun deletePointsForScript(scriptId: Long)

    @Query("DELETE FROM click_scripts WHERE id = :scriptId")
    suspend fun deleteScriptById(scriptId: Long)

    @Transaction
    suspend fun saveScriptWithPoints(
        script: ClickScriptEntity,
        points: List<ClickPointEntity>,
    ): Long {
        val scriptId = if (script.id == 0L) {
            insertScript(script)
        } else {
            updateScript(script)
            deletePointsForScript(script.id)
            script.id
        }
        if (points.isNotEmpty()) {
            insertPoints(
                points.mapIndexed { idx, p ->
                    p.copy(id = 0L, scriptId = scriptId, orderIndex = idx + 1)
                },
            )
        }
        return scriptId
    }
}
