package com.example.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.example.data.model.ClickMode
import com.example.data.model.ClickScript
import com.example.data.model.ClickTarget
import com.example.data.model.StopConditionType
import com.example.data.model.TargetActionType

@Entity(tableName = "click_scripts")
data class ClickScriptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val mode: String,
    val intervalMs: Long,
    val holdDurationMs: Long,
    val stopConditionType: String,
    val stopCount: Int,
    val stopTimerSeconds: Int,
    val randomizeTiming: Boolean,
    val randomizePosition: Boolean,
    val updatedAt: Long,
)

@Entity(
    tableName = "click_points",
    foreignKeys = [
        ForeignKey(
            entity = ClickScriptEntity::class,
            parentColumns = ["id"],
            childColumns = ["scriptId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["scriptId"])],
)
data class ClickPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val scriptId: Long,
    val orderIndex: Int,
    val actionType: String,
    val x: Float,
    val y: Float,
    val endX: Float? = null,
    val endY: Float? = null,
    val delayAfterMs: Long,
    val holdDurationMs: Long,
)

data class ClickScriptWithPoints(
    @Embedded val script: ClickScriptEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "scriptId",
    )
    val points: List<ClickPointEntity>,
)

fun ClickScriptWithPoints.toDomain(): ClickScript {
    val parsedMode = runCatching { ClickMode.valueOf(script.mode) }.getOrDefault(ClickMode.SINGLE)
    val parsedStop = runCatching { StopConditionType.valueOf(script.stopConditionType) }
        .getOrDefault(StopConditionType.INFINITE)
    val sortedPoints = points.sortedBy { it.orderIndex }.mapIndexed { idx, p ->
        ClickTarget(
            id = p.id,
            orderIndex = idx + 1,
            actionType = runCatching { TargetActionType.valueOf(p.actionType) }
                .getOrDefault(TargetActionType.TAP),
            x = p.x,
            y = p.y,
            endX = p.endX,
            endY = p.endY,
            delayAfterMs = p.delayAfterMs,
            holdDurationMs = p.holdDurationMs,
        )
    }
    return ClickScript(
        id = script.id,
        name = script.name,
        mode = parsedMode,
        intervalMs = script.intervalMs,
        holdDurationMs = script.holdDurationMs,
        stopConditionType = parsedStop,
        stopCount = script.stopCount,
        stopTimerSeconds = script.stopTimerSeconds,
        randomizeTiming = script.randomizeTiming,
        randomizePosition = script.randomizePosition,
        targets = sortedPoints,
        updatedAt = script.updatedAt,
    )
}
