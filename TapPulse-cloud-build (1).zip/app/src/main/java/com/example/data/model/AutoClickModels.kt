package com.example.data.model

enum class ClickMode {
    SINGLE,
    MULTI,
    SWIPE,
}

enum class StopConditionType {
    INFINITE,
    COUNT,
    TIMER,
}

enum class TargetActionType {
    TAP,
    SWIPE,
}

data class ClickTarget(
    val id: Long,
    val orderIndex: Int,
    val actionType: TargetActionType = TargetActionType.TAP,
    val x: Float,
    val y: Float,
    val endX: Float? = null,
    val endY: Float? = null,
    val delayAfterMs: Long = 120L,
    val holdDurationMs: Long = 45L,
)

data class ClickScript(
    val id: Long = 0L,
    val name: String,
    val mode: ClickMode = ClickMode.SINGLE,
    val intervalMs: Long = 120L,
    val holdDurationMs: Long = 45L,
    val stopConditionType: StopConditionType = StopConditionType.INFINITE,
    val stopCount: Int = 100,
    val stopTimerSeconds: Int = 60,
    val randomizeTiming: Boolean = false,
    val randomizePosition: Boolean = false,
    val targets: List<ClickTarget> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis(),
)

data class OverlayAppearancePrefs(
    val overlayOpacity: Float = 0.92f,
    val targetBubbleSizeDp: Int = 46,
    val useDynamicColor: Boolean = false,
    val defaultIntervalMs: Long = 120L,
    val defaultHoldMs: Long = 45L,
)
