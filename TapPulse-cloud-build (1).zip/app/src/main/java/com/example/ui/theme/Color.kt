package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Precision Kinetic Obsidian & Electric Cyan palette
val CyanPulse = Color(0xFF00E5CC)
val CyanPulseDeep = Color(0xFF00796B)
val CyanContainerDark = Color(0xFF004D43)
val CyanOnContainerDark = Color(0xFF7BF8E5)
val CyanContainerLight = Color(0xFFB8F3EA)
val CyanOnContainerLight = Color(0xFF00251F)

val SkySignal = Color(0xFF38BDF8)
val SkySignalDark = Color(0xFF0284C7)

val CoralActive = Color(0xFFFF6B4A)
val CoralContainerDark = Color(0xFF5A1E11)
val CoralOnContainerDark = Color(0xFFFFDAD2)

val ObsidianBg = Color(0xFF080E17)
val ObsidianSurface = Color(0xFF0F1826)
val ObsidianSurfaceElevated = Color(0xFF162336)
val ObsidianSurfaceHighest = Color(0xFF1E2F47)
val ObsidianOutline = Color(0xFF2B3E59)

val AlabasterBg = Color(0xFFF3F7FA)
val AlabasterSurface = Color(0xFFFFFFFF)
val AlabasterSurfaceElevated = Color(0xFFEAF1F6)
val AlabasterOutline = Color(0xFFC8D6E2)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

val SuccessGreen = Color(0xFF22C55E)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRose = Color(0xFFFF5370)
