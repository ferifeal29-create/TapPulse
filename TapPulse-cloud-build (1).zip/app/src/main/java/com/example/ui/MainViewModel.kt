package com.example.ui

import android.app.Application
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ScriptRepository
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesRepository
import com.example.data.model.ClickMode
import com.example.data.model.ClickScript
import com.example.data.model.ClickTarget
import com.example.data.model.OverlayAppearancePrefs
import com.example.data.model.StopConditionType
import com.example.data.model.TargetActionType
import com.example.service.AutoClickEngineBridge
import com.example.service.EngineSnapshot
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ArenaUiState(
    val tapCount: Long = 0L,
    val liveCps: Float = 0f,
    val peakCps: Float = 0f,
    val avgIntervalMs: Long = 0L,
    val pulseTriggerId: Long = 0L,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val scriptRepository = ScriptRepository(database.scriptDao())
    private val prefsRepository = PreferencesRepository(application)

    val engineState: StateFlow<EngineSnapshot> = AutoClickEngineBridge.snapshot

    val scripts: StateFlow<List<ClickScript>> = scriptRepository.scriptsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList(),
        )

    val appearancePrefs: StateFlow<OverlayAppearancePrefs> = prefsRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = OverlayAppearancePrefs(),
        )

    private val _isAccessibilityGranted = MutableStateFlow(
        AutoClickEngineBridge.isAccessibilityEnabledInSettings(application),
    )
    val isAccessibilityGranted: StateFlow<Boolean> = _isAccessibilityGranted.asStateFlow()

    private val _arenaState = MutableStateFlow(ArenaUiState())
    val arenaState: StateFlow<ArenaUiState> = _arenaState.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    private val recentTapTimestamps = ArrayDeque<Long>()
    private var lastTapElapsedMs: Long = 0L

    init {
        val (w, h) = getScreenSizePx()
        AutoClickEngineBridge.ensureDefaultTargets(w, h)
        viewModelScope.launch {
            scriptRepository.ensureStarterPresets(w, h)
        }
        viewModelScope.launch {
            prefsRepository.preferencesFlow.collect { prefs ->
                AutoClickEngineBridge.applyAppearancePrefs(prefs)
            }
        }
    }

    private fun getScreenSizePx(): Pair<Int, Int> {
        val wm = getApplication<Application>().getSystemService(WindowManager::class.java)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm?.defaultDisplay?.getRealMetrics(metrics)
        val w = if (metrics.widthPixels > 0) metrics.widthPixels else 1080
        val h = if (metrics.heightPixels > 0) metrics.heightPixels else 2400
        return w to h
    }

    fun refreshAccessibilityStatus() {
        val enabled = AutoClickEngineBridge.isAccessibilityEnabledInSettings(getApplication())
        _isAccessibilityGranted.value = enabled
        if (enabled && AutoClickEngineBridge.snapshot.value.isServiceConnected.not()) {
            // AccessibilityManager reports enabled; service connects momentarily via onServiceConnected
        }
    }

    fun setMode(mode: ClickMode) {
        val (w, h) = getScreenSizePx()
        AutoClickEngineBridge.setMode(mode, w, h)
    }

    fun updateTimingConfig(
        intervalMs: Long? = null,
        holdDurationMs: Long? = null,
        stopConditionType: StopConditionType? = null,
        stopCount: Int? = null,
        stopTimerSeconds: Int? = null,
        randomizeTiming: Boolean? = null,
        randomizePosition: Boolean? = null,
    ) {
        AutoClickEngineBridge.updateTimingConfig(
            intervalMs = intervalMs,
            holdDurationMs = holdDurationMs,
            stopConditionType = stopConditionType,
            stopCount = stopCount,
            stopTimerSeconds = stopTimerSeconds,
            randomizeTiming = randomizeTiming,
            randomizePosition = randomizePosition,
        )
    }

    fun addTarget(actionType: TargetActionType) {
        val (w, h) = getScreenSizePx()
        AutoClickEngineBridge.addTarget(actionType, w, h)
    }

    fun removeTargetById(targetId: Long) {
        AutoClickEngineBridge.removeTargetById(targetId)
    }

    fun updateTargetTiming(targetId: Long, delayAfterMs: Long, holdDurationMs: Long) {
        AutoClickEngineBridge.updateTargetTiming(targetId, delayAfterMs, holdDurationMs)
    }

    fun toggleOverlay(): Boolean {
        refreshAccessibilityStatus()
        val snap = AutoClickEngineBridge.snapshot.value
        if (!snap.isServiceConnected && !_isAccessibilityGranted.value) {
            return false
        }
        if (snap.isOverlayVisible) {
            AutoClickEngineBridge.requestHideOverlay()
        } else {
            AutoClickEngineBridge.requestShowOverlay()
        }
        return true
    }

    fun showOverlayIfPermitted(): Boolean {
        refreshAccessibilityStatus()
        val snap = AutoClickEngineBridge.snapshot.value
        if (!snap.isServiceConnected && !_isAccessibilityGranted.value) {
            return false
        }
        AutoClickEngineBridge.requestShowOverlay()
        return true
    }

    fun toggleClicking(): Boolean {
        refreshAccessibilityStatus()
        val snap = AutoClickEngineBridge.snapshot.value
        if (!snap.isServiceConnected && !_isAccessibilityGranted.value) {
            return false
        }
        if (!snap.isOverlayVisible) {
            AutoClickEngineBridge.requestShowOverlay()
        }
        if (snap.isClickingActive) {
            AutoClickEngineBridge.requestStopClicking()
        } else {
            AutoClickEngineBridge.requestStartClicking()
        }
        return true
    }

    fun saveCurrentAsPreset(name: String) {
        val snap = AutoClickEngineBridge.snapshot.value
        val (w, h) = getScreenSizePx()
        val targetsToSave = snap.targets.ifEmpty {
            listOf(
                ClickTarget(
                    id = 1L,
                    orderIndex = 1,
                    actionType = TargetActionType.TAP,
                    x = w * 0.5f,
                    y = h * 0.5f,
                    delayAfterMs = snap.intervalMs,
                    holdDurationMs = snap.holdDurationMs,
                ),
            )
        }
        viewModelScope.launch {
            val newId = scriptRepository.saveScript(
                ClickScript(
                    id = 0L,
                    name = name,
                    mode = snap.mode,
                    intervalMs = snap.intervalMs,
                    holdDurationMs = snap.holdDurationMs,
                    stopConditionType = snap.stopConditionType,
                    stopCount = snap.stopCount,
                    stopTimerSeconds = snap.stopTimerSeconds,
                    randomizeTiming = snap.randomizeTiming,
                    randomizePosition = snap.randomizePosition,
                    targets = targetsToSave,
                ),
            )
            _snackbarEvents.tryEmit("Preset \"$name\" tersimpan (#$newId)")
        }
    }

    fun saveScript(script: ClickScript) {
        viewModelScope.launch {
            val finalTargets = if (script.targets.isEmpty()) {
                val (w, h) = getScreenSizePx()
                val cx = w * 0.5f
                val cy = h * 0.5f
                if (script.mode == ClickMode.SWIPE) {
                    listOf(
                        ClickTarget(
                            id = 1L,
                            orderIndex = 1,
                            actionType = TargetActionType.SWIPE,
                            x = cx,
                            y = h * 0.68f,
                            endX = cx,
                            endY = h * 0.30f,
                            delayAfterMs = script.intervalMs,
                            holdDurationMs = script.holdDurationMs.coerceAtLeast(300L),
                        ),
                    )
                } else {
                    listOf(
                        ClickTarget(
                            id = 1L,
                            orderIndex = 1,
                            actionType = TargetActionType.TAP,
                            x = cx,
                            y = cy,
                            delayAfterMs = script.intervalMs,
                            holdDurationMs = script.holdDurationMs,
                        ),
                    )
                }
            } else {
                script.targets
            }
            scriptRepository.saveScript(script.copy(targets = finalTargets))
            _snackbarEvents.tryEmit("Preset \"${script.name}\" disimpan")
        }
    }

    fun loadPreset(script: ClickScript, openOverlay: Boolean): Boolean {
        AutoClickEngineBridge.loadScript(script)
        if (openOverlay) {
            val permitted = showOverlayIfPermitted()
            if (permitted) {
                _snackbarEvents.tryEmit("Memuat \"${script.name}\" ke panel mengambang")
            }
            return permitted
        }
        _snackbarEvents.tryEmit("Konfigurasi \"${script.name}\" dimuat")
        return true
    }

    fun duplicatePreset(script: ClickScript) {
        viewModelScope.launch {
            scriptRepository.duplicateScript(script)
            _snackbarEvents.tryEmit("Preset diduplikasi")
        }
    }

    fun deletePreset(script: ClickScript) {
        viewModelScope.launch {
            scriptRepository.deleteScript(script.id)
            _snackbarEvents.tryEmit("Preset \"${script.name}\" dihapus")
        }
    }

    fun updateOverlayOpacity(opacity: Float) {
        viewModelScope.launch {
            prefsRepository.updateOverlayOpacity(opacity)
        }
    }

    fun updateTargetBubbleSize(sizeDp: Int) {
        viewModelScope.launch {
            prefsRepository.updateTargetBubbleSize(sizeDp)
        }
    }

    fun updateDynamicColor(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.updateDynamicColor(enabled)
        }
    }

    fun recordArenaTap() {
        val now = SystemClock.elapsedRealtime()
        recentTapTimestamps.addLast(now)
        val cutoff = now - 1000L
        while (recentTapTimestamps.isNotEmpty() && recentTapTimestamps.first() < cutoff) {
            recentTapTimestamps.removeFirst()
        }
        val instantCps = recentTapTimestamps.size.toFloat()
        val delta = if (lastTapElapsedMs > 0L) (now - lastTapElapsedMs).coerceAtLeast(1L) else 0L
        lastTapElapsedMs = now

        _arenaState.update { prev ->
            val nextCount = prev.tapCount + 1L
            val smoothedAvg = when {
                delta == 0L -> prev.avgIntervalMs
                prev.avgIntervalMs == 0L -> delta
                else -> ((prev.avgIntervalMs * 0.7f) + (delta * 0.3f)).toLong()
            }
            ArenaUiState(
                tapCount = nextCount,
                liveCps = instantCps,
                peakCps = maxOf(prev.peakCps, instantCps),
                avgIntervalMs = smoothedAvg,
                pulseTriggerId = prev.pulseTriggerId + 1L,
            )
        }
    }

    fun resetArenaStats() {
        recentTapTimestamps.clear()
        lastTapElapsedMs = 0L
        _arenaState.value = ArenaUiState()
    }
}
