package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ClickMode
import com.example.data.model.ClickScript
import com.example.data.model.ClickTarget
import com.example.data.model.StopConditionType

@Composable
fun AccessibilityDisclosureDialog(
    onConfirmOpenSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Rounded.AccessibilityNew,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
        },
        title = {
            Text(
                text = stringResource(R.string.disclosure_title),
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = stringResource(R.string.disclosure_body),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Security,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = "Privasi terjaga • Hanya API gestur lokal",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmOpenSettings,
                modifier = Modifier.testTag("confirm_accessibility_settings_button"),
            ) {
                Text(stringResource(R.string.btn_understand_continue))
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_accessibility_dialog_button"),
            ) {
                Text(stringResource(R.string.btn_cancel))
            }
        },
    )
}

@Composable
fun SavePresetDialog(
    initialName: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initialName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Rounded.BookmarkAdd,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
        },
        title = { Text("Simpan Konfigurasi Preset") },
        text = {
            Column {
                Text(
                    text = "Simpan seluruh posisi titik target, interval, dan pengaturan berhenti agar bisa dipakai ulang kapan saja.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Preset") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_preset_name_input"),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name.trim().ifEmpty { "Preset Kustom" }) },
                modifier = Modifier.testTag("confirm_save_preset_button"),
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        },
    )
}

@Composable
fun TargetTimingDialog(
    target: ClickTarget,
    onSave: (delayAfterMs: Long, holdDurationMs: Long) -> Unit,
    onDismiss: () -> Unit,
) {
    var delayText by remember(target.id) { mutableStateOf(target.delayAfterMs.toString()) }
    var holdText by remember(target.id) { mutableStateOf(target.holdDurationMs.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Rounded.Tune,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
        },
        title = { Text("Atur Titik #${target.orderIndex}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Posisi: (${target.x.toInt()}, ${target.y.toInt()})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                OutlinedTextField(
                    value = delayText,
                    onValueChange = { delayText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Jeda setelah klik (ms, min 25)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("target_delay_input"),
                )
                OutlinedTextField(
                    value = holdText,
                    onValueChange = { holdText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Durasi tahan sentuhan (ms)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("target_hold_input"),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val delayVal = (delayText.toLongOrNull() ?: target.delayAfterMs).coerceAtLeast(25L)
                    val holdVal = (holdText.toLongOrNull() ?: target.holdDurationMs).coerceIn(15L, 5000L)
                    onSave(delayVal, holdVal)
                },
                modifier = Modifier.testTag("confirm_target_timing_button"),
            ) {
                Text("Terapkan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        },
    )
}

@Composable
fun PresetEditorDialog(
    initialScript: ClickScript?,
    onSave: (ClickScript) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initialScript?.name ?: "Preset Baru") }
    var mode by remember { mutableStateOf(initialScript?.mode ?: ClickMode.SINGLE) }
    var intervalText by remember { mutableStateOf((initialScript?.intervalMs ?: 120L).toString()) }
    var holdText by remember { mutableStateOf((initialScript?.holdDurationMs ?: 45L).toString()) }
    var stopType by remember {
        mutableStateOf(initialScript?.stopConditionType ?: StopConditionType.INFINITE)
    }
    var stopCountText by remember { mutableStateOf((initialScript?.stopCount ?: 100).toString()) }
    var stopTimerText by remember {
        mutableStateOf((initialScript?.stopTimerSeconds ?: 60).toString())
    }
    var randomTiming by remember { mutableStateOf(initialScript?.randomizeTiming ?: false) }
    var randomPos by remember { mutableStateOf(initialScript?.randomizePosition ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialScript == null) "Buat Preset Baru" else "Edit Preset")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Preset") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("preset_editor_name_input"),
                )
                Text("Mode Ketuk", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ClickMode.entries.forEach { m ->
                        val label = when (m) {
                            ClickMode.SINGLE -> "Tunggal"
                            ClickMode.MULTI -> "Multi"
                            ClickMode.SWIPE -> "Geser"
                        }
                        FilterChip(
                            selected = mode == m,
                            onClick = { mode = m },
                            label = { Text(label) },
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = intervalText,
                        onValueChange = { intervalText = it.filter { c -> c.isDigit() } },
                        label = { Text("Interval (ms)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = holdText,
                        onValueChange = { holdText = it.filter { c -> c.isDigit() } },
                        label = { Text("Tahan (ms)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                }
                Text("Kondisi Berhenti", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StopConditionType.entries.forEach { s ->
                        val label = when (s) {
                            StopConditionType.INFINITE -> "Terus"
                            StopConditionType.COUNT -> "Siklus"
                            StopConditionType.TIMER -> "Timer"
                        }
                        FilterChip(
                            selected = stopType == s,
                            onClick = { stopType = s },
                            label = { Text(label) },
                        )
                    }
                }
                if (stopType == StopConditionType.COUNT) {
                    OutlinedTextField(
                        value = stopCountText,
                        onValueChange = { stopCountText = it.filter { c -> c.isDigit() } },
                        label = { Text("Jumlah siklus sebelum berhenti") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else if (stopType == StopConditionType.TIMER) {
                    OutlinedTextField(
                        value = stopTimerText,
                        onValueChange = { stopTimerText = it.filter { c -> c.isDigit() } },
                        label = { Text("Durasi timer (detik)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Variasi jeda acak (±15%)",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = randomTiming, onCheckedChange = { randomTiming = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Geser posisi mikro (±6 px)",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = randomPos, onCheckedChange = { randomPos = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val interval = (intervalText.toLongOrNull() ?: 120L).coerceAtLeast(25L)
                    val hold = (holdText.toLongOrNull() ?: 45L).coerceIn(15L, 5000L)
                    val count = (stopCountText.toIntOrNull() ?: 100).coerceAtLeast(1)
                    val timer = (stopTimerText.toIntOrNull() ?: 60).coerceAtLeast(1)
                    val base = initialScript ?: ClickScript(name = name)
                    onSave(
                        base.copy(
                            name = name.trim().ifEmpty { "Preset Baru" },
                            mode = mode,
                            intervalMs = interval,
                            holdDurationMs = hold,
                            stopConditionType = stopType,
                            stopCount = count,
                            stopTimerSeconds = timer,
                            randomizeTiming = randomTiming,
                            randomizePosition = randomPos,
                        ),
                    )
                },
                modifier = Modifier.testTag("confirm_preset_editor_button"),
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        },
    )
}
