package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ClickMode
import com.example.data.model.ClickScript
import com.example.data.model.OverlayAppearancePrefs
import com.example.data.model.StopConditionType
import com.example.ui.components.PresetEditorDialog
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PresetsScreen(
    scripts: List<ClickScript>,
    activeScriptId: Long?,
    appearancePrefs: OverlayAppearancePrefs,
    onLoadScript: (ClickScript) -> Unit,
    onSaveScript: (ClickScript) -> Unit,
    onDuplicateScript: (ClickScript) -> Unit,
    onDeleteScript: (ClickScript) -> Unit,
    onUpdateOpacity: (Float) -> Unit,
    onUpdateBubbleSize: (Int) -> Unit,
    onUpdateDynamicColor: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    var editingScript by remember { mutableStateOf<ClickScript?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.presets_title),
                            style = MaterialTheme.typography.headlineSmall,
                        )
                        Text(
                            text = "${scripts.size} konfigurasi tersimpan lokal",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    FilledTonalButton(
                        onClick = { showCreateDialog = true },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("create_preset_button"),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.btn_new_preset))
                    }
                }
            }

            if (scripts.isEmpty()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "Belum ada preset tersimpan",
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Text(
                                text = "Ketuk \"Buat Preset\" untuk menyimpan pola ketukan favorit Anda.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            } else {
                items(scripts, key = { it.id }) { script ->
                    PresetCard(
                        script = script,
                        isActive = script.id == activeScriptId,
                        onLoad = { onLoadScript(script) },
                        onEdit = { editingScript = script },
                        onDuplicate = { onDuplicateScript(script) },
                        onDelete = { onDeleteScript(script) },
                    )
                }
            }

            // Overlay Appearance & Preferences Section
            item {
                Spacer(Modifier.height(4.dp))
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.section_overlay_appearance),
                            style = MaterialTheme.typography.titleMedium,
                        )

                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = stringResource(R.string.label_overlay_opacity),
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                Text(
                                    text = "${(appearancePrefs.overlayOpacity * 100).roundToInt()}%",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Slider(
                                value = appearancePrefs.overlayOpacity,
                                onValueChange = onUpdateOpacity,
                                valueRange = 0.5f..1.0f,
                                modifier = Modifier.testTag("overlay_opacity_slider"),
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = stringResource(R.string.label_target_size),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(38 to "Kecil", 46 to "Sedang", 56 to "Besar").forEach { (dpVal, label) ->
                                    FilterChip(
                                        selected = appearancePrefs.targetBubbleSizeDp == dpVal,
                                        onClick = { onUpdateBubbleSize(dpVal) },
                                        label = { Text("$label (${dpVal}dp)") },
                                        modifier = Modifier.testTag("bubble_size_$dpVal"),
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = stringResource(R.string.label_dynamic_color),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                            )
                            Switch(
                                checked = appearancePrefs.useDynamicColor,
                                onCheckedChange = onUpdateDynamicColor,
                                modifier = Modifier.testTag("dynamic_color_switch"),
                            )
                        }
                    }
                }
            }

            // Privacy & Accessibility Guarantee Card
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Keamanan & Aksesibilitas",
                                style = MaterialTheme.typography.titleSmall,
                            )
                            Text(
                                text = "TapPulse bekerja sepenuhnya offline di perangkat Anda. Izin AccessibilityService hanya dipakai untuk mengirim gestur ketuk/geser dan tidak membaca konten layar apa pun.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (showCreateDialog) {
        PresetEditorDialog(
            initialScript = null,
            onSave = { newScript ->
                showCreateDialog = false
                onSaveScript(newScript)
            },
            onDismiss = { showCreateDialog = false },
        )
    }

    editingScript?.let { script ->
        PresetEditorDialog(
            initialScript = script,
            onSave = { updated ->
                editingScript = null
                onSaveScript(updated)
            },
            onDismiss = { editingScript = null },
        )
    }
}

@Composable
private fun PresetCard(
    script: ClickScript,
    isActive: Boolean,
    onLoad: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    val modeLabel = when (script.mode) {
        ClickMode.SINGLE -> "Tunggal"
        ClickMode.MULTI -> "Multi (${script.targets.size} titik)"
        ClickMode.SWIPE -> "Geser"
    }
    val stopLabel = when (script.stopConditionType) {
        StopConditionType.INFINITE -> "Tanpa batas"
        StopConditionType.COUNT -> "${script.stopCount} siklus"
        StopConditionType.TIMER -> "${script.stopTimerSeconds} detik"
    }

    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isActive) 1.5.dp else 1.dp,
            color = if (isActive) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outlineVariant
            },
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = script.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "$modeLabel • ${script.intervalMs}ms • $stopLabel",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                if (isActive) {
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Text(
                            text = "AKTIF",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Button(
                    onClick = onLoad,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("load_preset_${script.id}"),
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.btn_load_preset))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.testTag("edit_preset_${script.id}"),
                    ) {
                        Icon(
                            Icons.Rounded.Edit,
                            contentDescription = stringResource(R.string.btn_edit),
                        )
                    }
                    IconButton(
                        onClick = onDuplicate,
                        modifier = Modifier.testTag("duplicate_preset_${script.id}"),
                    ) {
                        Icon(
                            Icons.Rounded.ContentCopy,
                            contentDescription = stringResource(R.string.btn_duplicate),
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_preset_${script.id}"),
                    ) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = stringResource(R.string.btn_delete),
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }
        }
    }
}
