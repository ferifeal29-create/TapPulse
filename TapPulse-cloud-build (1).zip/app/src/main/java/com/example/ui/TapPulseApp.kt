package com.example.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.ui.components.AccessibilityDisclosureDialog
import com.example.ui.screens.ArenaScreen
import com.example.ui.screens.ControlScreen
import com.example.ui.screens.PresetsScreen
import com.example.ui.theme.TapPulseTheme

const val ROUTE_CONTROL = "control"
const val ROUTE_ARENA = "arena"
const val ROUTE_PRESETS = "presets"

private data class NavDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)

private val TopDestinations = listOf(
    NavDestination(
        route = ROUTE_CONTROL,
        labelRes = R.string.nav_control,
        selectedIcon = Icons.Rounded.Tune,
        unselectedIcon = Icons.Outlined.Tune,
        testTag = "nav_control_tab",
    ),
    NavDestination(
        route = ROUTE_ARENA,
        labelRes = R.string.nav_arena,
        selectedIcon = Icons.Rounded.Radar,
        unselectedIcon = Icons.Outlined.Radar,
        testTag = "nav_arena_tab",
    ),
    NavDestination(
        route = ROUTE_PRESETS,
        labelRes = R.string.nav_presets,
        selectedIcon = Icons.Rounded.Bookmark,
        unselectedIcon = Icons.Outlined.BookmarkBorder,
        testTag = "nav_presets_tab",
    ),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TapPulseApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    val scripts by viewModel.scripts.collectAsStateWithLifecycle()
    val appearancePrefs by viewModel.appearancePrefs.collectAsStateWithLifecycle()
    val isAccessibilityGranted by viewModel.isAccessibilityGranted.collectAsStateWithLifecycle()
    val arenaState by viewModel.arenaState.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showDisclosureDialog by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshAccessibilityStatus()
    }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    LaunchedEffect(engineState.lastError) {
        engineState.lastError?.let { err ->
            snackbarHostState.showSnackbar(err)
        }
    }

    val openAccessibilitySettings: () -> Unit = {
        showDisclosureDialog = false
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    TapPulseTheme(dynamicColor = appearancePrefs.useDynamicColor) {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_CONTROL

        val navigateToTab: (String) -> Unit = { route ->
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.headlineSmall,
                            )
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background,
                            titleContentColor = MaterialTheme.colorScheme.onBackground,
                        ),
                    )
                },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar {
                            TopDestinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = stringResource(dest.labelRes),
                                        )
                                    },
                                    label = { Text(stringResource(dest.labelRes)) },
                                    modifier = Modifier.testTag(dest.testTag),
                                )
                            }
                        }
                    }
                },
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                ) {
                    if (useRail) {
                        NavigationRail(modifier = Modifier.fillMaxHeight()) {
                            TopDestinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = stringResource(dest.labelRes),
                                        )
                                    },
                                    label = { Text(stringResource(dest.labelRes)) },
                                    modifier = Modifier.testTag(dest.testTag),
                                )
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        NavHost(
                            navController = navController,
                            startDestination = ROUTE_CONTROL,
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            composable(ROUTE_CONTROL) {
                                ControlScreen(
                                    engineState = engineState,
                                    isAccessibilityGranted = isAccessibilityGranted,
                                    onRequestAccessibilitySetup = { showDisclosureDialog = true },
                                    onToggleOverlay = {
                                        if (!viewModel.toggleOverlay()) {
                                            showDisclosureDialog = true
                                        }
                                    },
                                    onToggleClicking = {
                                        if (!viewModel.toggleClicking()) {
                                            showDisclosureDialog = true
                                        }
                                    },
                                    onSelectMode = viewModel::setMode,
                                    onUpdateTiming = viewModel::updateTimingConfig,
                                    onAddTarget = viewModel::addTarget,
                                    onRemoveTarget = viewModel::removeTargetById,
                                    onUpdateTargetTiming = viewModel::updateTargetTiming,
                                    onSavePreset = viewModel::saveCurrentAsPreset,
                                )
                            }

                            composable(ROUTE_ARENA) {
                                ArenaScreen(
                                    arenaState = arenaState,
                                    isOverlayVisible = engineState.isOverlayVisible,
                                    onTapArena = viewModel::recordArenaTap,
                                    onResetStats = viewModel::resetArenaStats,
                                    onOpenOverlayHere = {
                                        if (!viewModel.showOverlayIfPermitted()) {
                                            showDisclosureDialog = true
                                        }
                                    },
                                )
                            }

                            composable(ROUTE_PRESETS) {
                                PresetsScreen(
                                    scripts = scripts,
                                    activeScriptId = engineState.activeScriptId,
                                    appearancePrefs = appearancePrefs,
                                    onLoadScript = { script ->
                                        val permitted = viewModel.loadPreset(script, openOverlay = true)
                                        if (!permitted) {
                                            showDisclosureDialog = true
                                        } else {
                                            navigateToTab(ROUTE_CONTROL)
                                        }
                                    },
                                    onSaveScript = viewModel::saveScript,
                                    onDuplicateScript = viewModel::duplicatePreset,
                                    onDeleteScript = viewModel::deletePreset,
                                    onUpdateOpacity = viewModel::updateOverlayOpacity,
                                    onUpdateBubbleSize = viewModel::updateTargetBubbleSize,
                                    onUpdateDynamicColor = viewModel::updateDynamicColor,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showDisclosureDialog) {
            AccessibilityDisclosureDialog(
                onConfirmOpenSettings = openAccessibilitySettings,
                onDismiss = { showDisclosureDialog = false },
            )
        }
    }
}
