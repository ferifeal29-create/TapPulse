package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.LayersClear
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.SwipeUp
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ClickMode
import com.example.data.model.ClickTarget
import com.example.data.model.StopConditionType
import com.example.data.model.TargetActionType
import com.example.service.EngineSnapshot
import com.example.ui.components.SavePresetDialog
import com.example.ui.components.TargetTimingDialog
import kotlin.math.roundToLong

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ControlScreen(
    engineState: EngineSnapshot,
    isAccessibilityGranted: Boolean,
    onRequestAccessibilitySetup: () -> Unit,
    onToggleOverlay: () -> Unit,
    onToggleClicking: () -> Unit,
    onSelectMode: (ClickMode) -> Unit,
    onUpdateTiming: (
        intervalMs: Long?,
        holdDurationMs: Long?,
        stopConditionType: StopConditionType?,
        stopCount: Int?,
        stopTimerSeconds: Int?,
        randomizeTiming: Boolean?,
        randomizePosition: Boolean?,
    ) -> Unit,
    onAddTarget: (TargetActionType) -> Unit,
    onRemoveTarget: (Long) -> Unit,
    onUpdateTargetTiming: (Long, Long, Long) -> Unit,
    onSavePreset: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val isServiceReady = engineState.isServiceConnected || isAccessibilityGranted
    var showSaveDialog by remember { mutableStateOf(false) }
    var editingTarget by remember { mutableStateOf<ClickTarget?>(null) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // 1. Hero Service Status & Floating Panel Launcher
            item {
                HeroStatusCard(
                    isServiceReady = isServiceReady,
                    isOverlayVisible = engineState.isOverlayVisible,
                    isClickingActive = engineState.isClickingActive,
                    activeScriptName = engineState.activeScriptName,
                    onRequestAccessibilitySetup = onRequestAccessibilitySetup,
                    onToggleOverlay = onToggleOverlay,
                    onToggleClicking = onToggleClicking,
                )
            }

            // 2. Live Session Telemetry Strip
            item {
                TelemetryStrip(engineState = engineState)
            }

            // 3. Automation Mode Selector
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.section_click_mode),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        ModeTile(
                            title = stringResource(R.string.mode_single_title),
                            subtitle = "1 Titik",
                            icon = Icons.Rounded.TouchApp,
                            selected = engineState.mode == ClickMode.SINGLE,
                            onClick = { onSelectMode(ClickMode.SINGLE) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mode_single_card"),
                        )
                        ModeTile(
                            title = stringResource(R.string.mode_multi_title),
                            subtitle = "Berantai",
                            icon = Icons.Rounded.Layers,
                            selected = engineState.mode == ClickMode.MULTI,
                            onClick = { onSelectMode(ClickMode.MULTI) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mode_multi_card"),
                        )
                        ModeTile(
                            title = stringResource(R.string.mode_swipe_title),
                            subtitle = "Scroll",
                            icon = Icons.Rounded.SwipeUp,
                            selected = engineState.mode == ClickMode.SWIPE,
                            onClick = { onSelectMode(ClickMode.SWIPE) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mode_swipe_card"),
                        )
                    }
                }
            }

            // 4. Speed, Hold & Stop Conditions Card
            item {
                TimingConfigurationCard(
                    engineState = engineState,
                    onUpdateTiming = onUpdateTiming,
                )
            }

            // 5. Active Targets List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.section_targets),
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            text = "Seret penanda pada panel mengambang untuk memindah koordinat",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalIconButton(
                            onClick = { showSaveDialog = true },
                            modifier = Modifier.testTag("open_save_preset_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.BookmarkAdd,
                                contentDescription = stringResource(R.string.btn_save_preset),
                            )
                        }
                        if (engineState.mode != ClickMode.SINGLE) {
                            FilledTonalIconButton(
                                onClick = {
                                    val type = if (engineState.mode == ClickMode.SWIPE) {
                                        TargetActionType.SWIPE
                                    } else {
                                        TargetActionType.TAP
                                    }
                                    onAddTarget(type)
                                },
                                modifier = Modifier.testTag("add_target_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Add,
                                    contentDescription = stringResource(R.string.btn_add_target),
                                )
                            }
                        }
                    }
                }
            }

            items(engineState.targets, key = { it.id }) { target ->
                TargetItemCard(
                    target = target,
                    canDelete = engineState.targets.size > 1,
                    onEditClick = { editingTarget = target },
                    onDeleteClick = { onRemoveTarget(target.id) },
                )
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (showSaveDialog) {
        SavePresetDialog(
            initialName = if (engineState.activeScriptName == "Konfigurasi Cepat") {
                "Preset ${engineState.intervalMs}ms"
            } else {
                engineState.activeScriptName
            },
            onSave = { name ->
                showSaveDialog = false
                onSavePreset(name)
            },
            onDismiss = { showSaveDialog = false },
        )
    }

    editingTarget?.let { target ->
        TargetTimingDialog(
            target = target,
            onSave = { delayMs, holdMs ->
                onUpdateTargetTiming(target.id, delayMs, holdMs)
                editingTarget = null
            },
            onDismiss = { editingTarget = null },
        )
    }
}

@Composable
private fun HeroStatusCard(
    isServiceReady: Boolean,
    isOverlayVisible: Boolean,
    isClickingActive: Boolean,
    activeScriptName: String,
    onRequestAccessibilitySetup: () -> Unit,
    onToggleOverlay: () -> Unit,
    onToggleClicking: () -> Unit,
) {
    val pulseTransition = rememberInfiniteTransition(label = "status_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse_scale",
    )

    Card(
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = 1.dp,
            color = if (isServiceReady) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.45f)
            },
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_pulse_1794938008465),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.24f,
                modifier = Modifier.matchParentSize(),
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.65f),
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                            ),
                        ),
                    ),
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isServiceReady) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.tertiaryContainer
                                    },
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = if (isServiceReady) {
                                    Icons.Rounded.CheckCircle
                                } else {
                                    Icons.Rounded.WarningAmber
                                },
                                contentDescription = null,
                                tint = if (isServiceReady) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.tertiary
                                },
                                modifier = if (isClickingActive) Modifier.scale(pulseScale) else Modifier,
                            )
                        }
                        Column {
                            Text(
                                text = stringResource(
                                    if (isServiceReady) R.string.status_service_active
                                    else R.string.status_service_inactive,
                                ),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = "Skrip: $activeScriptName",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isClickingActive) {
                            MaterialTheme.colorScheme.tertiaryContainer
                        } else if (isOverlayVisible) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHighest
                        },
                    ) {
                        Text(
                            text = when {
                                isClickingActive -> stringResource(R.string.overlay_running_badge)
                                isOverlayVisible -> stringResource(R.string.overlay_ready_badge)
                                else -> "NONAKTIF"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                isClickingActive -> MaterialTheme.colorScheme.tertiary
                                isOverlayVisible -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        )
                    }
                }

                Text(
                    text = stringResource(
                        if (isServiceReady) R.string.status_service_active_desc
                        else R.string.status_service_inactive_desc,
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                if (!isServiceReady) {
                    Button(
                        onClick = onRequestAccessibilitySetup,
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("enable_accessibility_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AccessibilityNew,
                            contentDescription = null,
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.btn_enable_accessibility))
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = onToggleOverlay,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isOverlayVisible) {
                                    MaterialTheme.colorScheme.surfaceContainerHighest
                                } else {
                                    MaterialTheme.colorScheme.primary
                                },
                                contentColor = if (isOverlayVisible) {
                                    MaterialTheme.colorScheme.onSurface
                                } else {
                                    MaterialTheme.colorScheme.onPrimary
                                },
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("toggle_overlay_button"),
                        ) {
                            Icon(
                                imageVector = if (isOverlayVisible) {
                                    Icons.Rounded.LayersClear
                                } else {
                                    Icons.Rounded.Layers
                                },
                                contentDescription = null,
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (isOverlayVisible) "Tutup Panel" else "Buka Panel",
                                maxLines = 1,
                            )
                        }

                        FilledTonalButton(
                            onClick = onToggleClicking,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (isClickingActive) {
                                    MaterialTheme.colorScheme.tertiaryContainer
                                } else {
                                    MaterialTheme.colorScheme.primaryContainer
                                },
                                contentColor = if (isClickingActive) {
                                    MaterialTheme.colorScheme.onTertiaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                },
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("toggle_clicking_button"),
                        ) {
                            Icon(
                                imageVector = if (isClickingActive) {
                                    Icons.Rounded.Pause
                                } else {
                                    Icons.Rounded.PlayArrow
                                },
                                contentDescription = null,
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (isClickingActive) "Jeda" else "Mulai",
                                maxLines = 1,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryStrip(engineState: EngineSnapshot) {
    val cps = if (engineState.sessionElapsedMs > 150L) {
        engineState.sessionClicks / (engineState.sessionElapsedMs / 1000f)
    } else {
        0f
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TelemetryChip(
            label = stringResource(R.string.telemetry_clicks),
            value = engineState.sessionClicks.toString(),
            modifier = Modifier.weight(1f),
        )
        TelemetryChip(
            label = stringResource(R.string.telemetry_elapsed),
            value = "${engineState.sessionElapsedMs / 1000}d",
            modifier = Modifier.weight(1f),
        )
        TelemetryChip(
            label = stringResource(R.string.telemetry_cps),
            value = String.format("%.1f", cps),
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun TelemetryChip(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = MaterialTheme.typography.labelMedium.fontFamily,
                ),
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun ModeTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val containerColor by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.surface
        },
        label = "mode_tile_bg",
    )
    val borderColor by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.outlineVariant
        },
        label = "mode_tile_border",
    )

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = containerColor,
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, borderColor),
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize(),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (selected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TimingConfigurationCard(
    engineState: EngineSnapshot,
    onUpdateTiming: (
        intervalMs: Long?,
        holdDurationMs: Long?,
        stopConditionType: StopConditionType?,
        stopCount: Int?,
        stopTimerSeconds: Int?,
        randomizeTiming: Boolean?,
        randomizePosition: Boolean?,
    ) -> Unit,
) {
    val quickIntervals = listOf(50L, 100L, 250L, 500L, 1000L)

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = stringResource(R.string.section_timing_config),
                style = MaterialTheme.typography.titleMedium,
            )

            // Interval selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = stringResource(R.string.label_interval_ms),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        IconButton(
                            onClick = {
                                onUpdateTiming(
                                    (engineState.intervalMs - 25L).coerceAtLeast(25L),
                                    null, null, null, null, null, null,
                                )
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("interval_decrease_button"),
                        ) {
                            Icon(Icons.Rounded.Remove, contentDescription = "Kurangi interval")
                        }
                        Text(
                            text = "${engineState.intervalMs} ms",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        IconButton(
                            onClick = {
                                onUpdateTiming(
                                    (engineState.intervalMs + 25L).coerceAtMost(5000L),
                                    null, null, null, null, null, null,
                                )
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("interval_increase_button"),
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Tambah interval")
                        }
                    }
                }

                Slider(
                    value = engineState.intervalMs.coerceIn(25L, 2000L).toFloat(),
                    onValueChange = {
                        onUpdateTiming(it.roundToLong(), null, null, null, null, null, null)
                    },
                    valueRange = 25f..2000f,
                    modifier = Modifier.testTag("interval_slider"),
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    quickIntervals.forEach { presetMs ->
                        FilterChip(
                            selected = engineState.intervalMs == presetMs,
                            onClick = {
                                onUpdateTiming(presetMs, null, null, null, null, null, null)
                            },
                            label = {
                                Text(
                                    text = if (presetMs >= 1000L) "1 dtk" else "${presetMs}ms",
                                    style = MaterialTheme.typography.labelMedium,
                                )
                            },
                            modifier = Modifier.testTag("quick_interval_$presetMs"),
                        )
                    }
                }
            }

            // Hold duration slider
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = stringResource(R.string.label_hold_ms),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = "${engineState.holdDurationMs} ms",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Slider(
                    value = engineState.holdDurationMs.coerceIn(20L, 1200L).toFloat(),
                    onValueChange = {
                        onUpdateTiming(null, it.roundToLong(), null, null, null, null, null)
                    },
                    valueRange = 20f..1200f,
                    modifier = Modifier.testTag("hold_duration_slider"),
                )
            }

            // Stop condition selector
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.label_stop_condition),
                    style = MaterialTheme.typography.titleSmall,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StopConditionType.entries.forEach { condition ->
                        val label = when (condition) {
                            StopConditionType.INFINITE -> stringResource(R.string.stop_infinite)
                            StopConditionType.COUNT -> stringResource(R.string.stop_count)
                            StopConditionType.TIMER -> stringResource(R.string.stop_timer)
                        }
                        FilterChip(
                            selected = engineState.stopConditionType == condition,
                            onClick = {
                                onUpdateTiming(null, null, condition, null, null, null, null)
                            },
                            label = { Text(label) },
                            modifier = Modifier.testTag("stop_condition_${condition.name.lowercase()}"),
                        )
                    }
                }

                AnimatedVisibility(visible = engineState.stopConditionType == StopConditionType.COUNT) {
                    var countStr by remember(engineState.stopCount) {
                        mutableStateOf(engineState.stopCount.toString())
                    }
                    OutlinedTextField(
                        value = countStr,
                        onValueChange = { raw ->
                            val clean = raw.filter { it.isDigit() }
                            countStr = clean
                            clean.toIntOrNull()?.let { v ->
                                if (v > 0) onUpdateTiming(null, null, null, v, null, null, null)
                            }
                        },
                        label = { Text("Berhenti setelah N siklus") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("stop_count_input"),
                    )
                }

                AnimatedVisibility(visible = engineState.stopConditionType == StopConditionType.TIMER) {
                    var secStr by remember(engineState.stopTimerSeconds) {
                        mutableStateOf(engineState.stopTimerSeconds.toString())
                    }
                    OutlinedTextField(
                        value = secStr,
                        onValueChange = { raw ->
                            val clean = raw.filter { it.isDigit() }
                            secStr = clean
                            clean.toIntOrNull()?.let { v ->
                                if (v > 0) onUpdateTiming(null, null, null, null, v, null, null)
                            }
                        },
                        label = { Text("Berhenti setelah N detik") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("stop_timer_input"),
                    )
                }
            }

            // Natural variation switches
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.label_anti_detect),
                    style = MaterialTheme.typography.titleSmall,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = stringResource(R.string.label_random_timing),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(
                        checked = engineState.randomizeTiming,
                        onCheckedChange = {
                            onUpdateTiming(null, null, null, null, null, it, null)
                        },
                        modifier = Modifier.testTag("random_timing_switch"),
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = stringResource(R.string.label_random_position),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(
                        checked = engineState.randomizePosition,
                        onCheckedChange = {
                            onUpdateTiming(null, null, null, null, null, null, it)
                        },
                        modifier = Modifier.testTag("random_position_switch"),
                    )
                }
            }
        }
    }
}

@Composable
private fun TargetItemCard(
    target: ClickTarget,
    canDelete: Boolean,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f),
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = target.orderIndex.toString(),
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Column {
                    Text(
                        text = if (target.actionType == TargetActionType.SWIPE) {
                            "Geser #${target.orderIndex}"
                        } else {
                            "Ketuk #${target.orderIndex}"
                        },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        text = if (target.actionType == TargetActionType.SWIPE) {
                            "(${target.x.toInt()}, ${target.y.toInt()}) -> (${target.endX?.toInt() ?: 0}, ${target.endY?.toInt() ?: 0}) • Jeda ${target.delayAfterMs}ms"
                        } else {
                            "Koordinat (${target.x.toInt()}, ${target.y.toInt()}) • Jeda ${target.delayAfterMs}ms"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onEditClick,
                    modifier = Modifier.testTag("edit_target_${target.orderIndex}"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = "Atur jeda titik ${target.orderIndex}",
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
                if (canDelete) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.testTag("delete_target_${target.orderIndex}"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Hapus titik ${target.orderIndex}",
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }
        }
    }
}
