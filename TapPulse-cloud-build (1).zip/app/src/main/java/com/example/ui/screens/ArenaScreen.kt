package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.ArenaUiState
import kotlinx.coroutines.delay

private data class RippleWave(
    val id: Long,
    val progress: Animatable<Float, *> = Animatable(0f),
)

@Composable
fun ArenaScreen(
    arenaState: ArenaUiState,
    isOverlayVisible: Boolean,
    onTapArena: () -> Unit,
    onResetStats: () -> Unit,
    onOpenOverlayHere: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val activeRipples = remember { mutableStateListOf<RippleWave>() }
    val padScale = remember { Animatable(1f) }

    LaunchedEffect(arenaState.pulseTriggerId) {
        if (arenaState.pulseTriggerId > 0L) {
            padScale.snapTo(0.95f)
            padScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium,
                ),
            )
        }
    }

    LaunchedEffect(arenaState.pulseTriggerId) {
        if (arenaState.pulseTriggerId > 0L) {
            val wave = RippleWave(id = arenaState.pulseTriggerId)
            activeRipples.add(wave)
            wave.progress.animateTo(1f, animationSpec = tween(550))
            delay(50)
            activeRipples.remove(wave)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.arena_title),
                        style = MaterialTheme.typography.headlineSmall,
                    )
                    Text(
                        text = stringResource(R.string.arena_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Metrics Grid (2x2)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        ArenaStatCard(
                            label = "Total Ketukan",
                            value = arenaState.tapCount.toString(),
                            accent = true,
                            modifier = Modifier.weight(1f),
                        )
                        ArenaStatCard(
                            label = "Kecepatan (CPS)",
                            value = String.format("%.1f/dtk", arenaState.liveCps),
                            accent = false,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        ArenaStatCard(
                            label = "Rekor Puncak",
                            value = String.format("%.1f CPS", arenaState.peakCps),
                            accent = false,
                            modifier = Modifier.weight(1f),
                        )
                        ArenaStatCard(
                            label = "Interval Rata-rata",
                            value = if (arenaState.avgIntervalMs > 0L) "${arenaState.avgIntervalMs} ms" else "—",
                            accent = false,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            // Concentric Tactile Tap Pad
            item {
                val primaryColor = MaterialTheme.colorScheme.primary
                val secondaryColor = MaterialTheme.colorScheme.tertiary
                val surfaceColor = MaterialTheme.colorScheme.surfaceContainerHigh

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Canvas(modifier = Modifier.size(290.dp)) {
                        val maxRadius = size.minDimension / 2f
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    primaryColor.copy(alpha = 0.22f),
                                    surfaceColor.copy(alpha = 0.05f),
                                ),
                            ),
                            radius = maxRadius,
                        )
                        drawCircle(
                            color = primaryColor.copy(alpha = 0.25f),
                            radius = maxRadius * 0.85f,
                            style = Stroke(width = 2.dp.toPx()),
                        )
                        drawCircle(
                            color = primaryColor.copy(alpha = 0.45f),
                            radius = maxRadius * 0.68f,
                            style = Stroke(width = 1.5.dp.toPx()),
                        )

                        activeRipples.forEach { wave ->
                            val p = wave.progress.value
                            drawCircle(
                                color = secondaryColor.copy(alpha = (1f - p) * 0.85f),
                                radius = maxRadius * (0.42f + 0.56f * p),
                                style = Stroke(width = (5f * (1f - p)).dp.toPx().coerceAtLeast(1f)),
                            )
                        }
                    }

                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary),
                        shadowElevation = 8.dp,
                        modifier = Modifier
                            .size(164.dp)
                            .scale(padScale.value)
                            .clip(CircleShape)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                onClick = onTapArena,
                            )
                            .testTag("arena_tap_pad"),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.TouchApp,
                                contentDescription = stringResource(R.string.arena_tap_here),
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(34.dp),
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = arenaState.tapCount.toString(),
                                style = MaterialTheme.typography.displaySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                            Text(
                                text = stringResource(R.string.arena_tap_here),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedButton(
                        onClick = onResetStats,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("arena_reset_button"),
                    ) {
                        Icon(Icons.Rounded.RestartAlt, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.arena_reset))
                    }
                    Button(
                        onClick = onOpenOverlayHere,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("arena_launch_overlay_button"),
                    ) {
                        Icon(Icons.Rounded.Layers, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (isOverlayVisible) "Panel Aktif" else "Buka Panel")
                    }
                }
            }

            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            text = "Tip: Buka Panel Mengambang, letakkan target #1 di tengah lingkaran di atas, lalu tekan Play pada panel mengambang untuk memverifikasi ketukan otomatis.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ArenaStatCard(
    label: String,
    value: String,
    accent: Boolean,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = if (accent) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        } else {
            MaterialTheme.colorScheme.surface
        },
        border = BorderStroke(
            width = 1.dp,
            color = if (accent) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
            } else {
                MaterialTheme.colorScheme.outlineVariant
            },
        ),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = MaterialTheme.typography.labelMedium.fontFamily,
                ),
                color = if (accent) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
            )
        }
    }
}
